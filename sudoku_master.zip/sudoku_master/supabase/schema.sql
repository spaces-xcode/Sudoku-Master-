-- Sudoku Master Database Schema for Supabase

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email TEXT UNIQUE NOT NULL,
    username TEXT,
    avatar_url TEXT,
    country TEXT,
    level INTEGER DEFAULT 1,
    xp INTEGER DEFAULT 0,
    coins INTEGER DEFAULT 0,
    games_played INTEGER DEFAULT 0,
    games_won INTEGER DEFAULT 0,
    perfect_games INTEGER DEFAULT 0,
    best_time_easy INTEGER DEFAULT 0,
    best_time_medium INTEGER DEFAULT 0,
    best_time_hard INTEGER DEFAULT 0,
    best_time_expert INTEGER DEFAULT 0,
    best_time_evil INTEGER DEFAULT 0,
    current_streak INTEGER DEFAULT 0,
    longest_streak INTEGER DEFAULT 0,
    last_daily_challenge TIMESTAMP,
    is_premium BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Achievements table
CREATE TABLE achievements (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    icon_name TEXT,
    target_value INTEGER NOT NULL,
    xp_reward INTEGER DEFAULT 0,
    coin_reward INTEGER DEFAULT 0,
    type TEXT NOT NULL
);

-- User achievements (progress)
CREATE TABLE user_achievements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    achievement_id TEXT REFERENCES achievements(id),
    current_progress INTEGER DEFAULT 0,
    is_unlocked BOOLEAN DEFAULT FALSE,
    unlocked_at TIMESTAMP WITH TIME ZONE,
    UNIQUE(user_id, achievement_id)
);

-- Daily challenges table
CREATE TABLE daily_challenges (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    date DATE UNIQUE NOT NULL,
    difficulty TEXT NOT NULL,
    puzzle JSONB NOT NULL,
    solution JSONB NOT NULL,
    total_xp_reward INTEGER DEFAULT 75,
    coin_reward INTEGER DEFAULT 25,
    badge_id INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- User daily challenge completions
CREATE TABLE user_daily_completions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    challenge_id UUID REFERENCES daily_challenges(id),
    best_time INTEGER,
    is_perfect BOOLEAN DEFAULT FALSE,
    xp_earned INTEGER DEFAULT 0,
    coins_earned INTEGER DEFAULT 0,
    completed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, challenge_id)
);

-- Matches history
CREATE TABLE matches (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    difficulty TEXT NOT NULL,
    time INTEGER NOT NULL,
    mistakes INTEGER DEFAULT 0,
    hints_used INTEGER DEFAULT 0,
    is_perfect BOOLEAN DEFAULT FALSE,
    is_daily BOOLEAN DEFAULT FALSE,
    xp_earned INTEGER DEFAULT 0,
    coins_earned INTEGER DEFAULT 0,
    completed_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Challenges between users
CREATE TABLE challenges (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sender_id UUID REFERENCES users(id) ON DELETE CASCADE,
    sender_name TEXT NOT NULL,
    receiver_id UUID REFERENCES users(id) ON DELETE CASCADE,
    difficulty TEXT NOT NULL,
    puzzle JSONB NOT NULL,
    is_completed BOOLEAN DEFAULT FALSE,
    sender_time INTEGER,
    receiver_time INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE
);

-- Rankings table
CREATE TABLE rankings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    weekly_score INTEGER DEFAULT 0,
    monthly_score INTEGER DEFAULT 0,
    all_time_score INTEGER DEFAULT 0,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id)
);

-- Tournaments table
CREATE TABLE tournaments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    description TEXT,
    start_date TIMESTAMP WITH TIME ZONE NOT NULL,
    end_date TIMESTAMP WITH TIME ZONE NOT NULL,
    difficulty TEXT NOT NULL,
    participant_count INTEGER DEFAULT 0,
    prize_pool INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tournament participants
CREATE TABLE tournament_participants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    tournament_id UUID REFERENCES tournaments(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    score INTEGER DEFAULT 0,
    rank INTEGER,
    UNIQUE(tournament_id, user_id)
);

-- Subscriptions table
CREATE TABLE subscriptions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    plan TEXT NOT NULL,
    status TEXT NOT NULL,
    start_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    end_date TIMESTAMP WITH TIME ZONE,
    UNIQUE(user_id)
);

-- Notifications table
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    body TEXT,
    type TEXT,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for better performance
CREATE INDEX idx_matches_user_id ON matches(user_id);
CREATE INDEX idx_matches_completed_at ON matches(completed_at);
CREATE INDEX idx_rankings_all_time ON rankings(all_time_score DESC);
CREATE INDEX idx_rankings_weekly ON rankings(weekly_score DESC);
CREATE INDEX idx_daily_challenges_date ON daily_challenges(date);
CREATE INDEX idx_user_achievements_user_id ON user_achievements(user_id);

-- RLS (Row Level Security) Policies

-- Enable RLS on all tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_daily_completions ENABLE ROW LEVEL SECURITY;
ALTER TABLE matches ENABLE ROW LEVEL SECURITY;
ALTER TABLE challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE rankings ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Users: Users can read their own data, update own data
CREATE POLICY "Users can view own profile" ON users
    FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update own profile" ON users
    FOR UPDATE USING (auth.uid() = id);

-- User achievements: Users can only see their own achievements
CREATE POLICY "Users can view own achievements" ON user_achievements
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can update own achievements" ON user_achievements
    FOR ALL USING (auth.uid() = user_id);

-- Matches: Users can see their own matches and all public matches
CREATE POLICY "Users can view own matches" ON matches
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own matches" ON matches
    FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Rankings: Everyone can view rankings, users can update own
CREATE POLICY "Everyone can view rankings" ON rankings
    FOR SELECT USING (true);

CREATE POLICY "Users can update own ranking" ON rankings
    FOR UPDATE USING (auth.uid() = user_id);

-- Daily challenges: Read-only for all
CREATE POLICY "Everyone can view daily challenges" ON daily_challenges
    FOR SELECT USING (true);

-- User daily completions: Users can only see their own
CREATE POLICY "Users can view own daily completions" ON user_daily_completions
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own daily completions" ON user_daily_completions
    FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Notifications: Users can only see their own
CREATE POLICY "Users can view own notifications" ON notifications
    FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can update own notifications" ON notifications
    FOR UPDATE USING (auth.uid() = user_id);

-- Insert default achievements
INSERT INTO achievements (id, name, description, icon_name, target_value, xp_reward, coin_reward, type) VALUES
    ('first_game', 'First Steps', 'Complete your first game', '🎮', 1, 10, 5, 'gamesPlayed'),
    ('games_10', 'Getting Started', 'Complete 10 games', '🎯', 10, 25, 10, 'gamesPlayed'),
    ('games_50', 'Dedicated Player', 'Complete 50 games', '⭐', 50, 50, 25, 'gamesPlayed'),
    ('games_100', 'Sudoku Enthusiast', 'Complete 100 games', '🏆', 100, 100, 50, 'gamesPlayed'),
    ('games_500', 'Sudoku Master', 'Complete 500 games', '👑', 500, 250, 100, 'gamesPlayed'),
    ('perfect_5', 'Perfect Start', 'Win 5 perfect games', '✨', 5, 30, 15, 'perfectGames'),
    ('perfect_25', 'Perfectionist', 'Win 25 perfect games', '💎', 25, 75, 40, 'perfectGames'),
    ('perfect_100', 'Flawless', 'Win 100 perfect games', '💫', 100, 200, 100, 'perfectGames'),
    ('streak_3', 'On Fire', 'Complete 3 day streak', '🔥', 3, 20, 10, 'streaks'),
    ('streak_7', 'Week Warrior', 'Complete 7 day streak', '📅', 7, 50, 25, 'streaks'),
    ('streak_30', 'Monthly Champion', 'Complete 30 day streak', '🏅', 30, 150, 75, 'streaks'),
    ('speed_demon_easy', 'Speed Demon - Easy', 'Complete Easy under 3 minutes', '⚡', 180, 25, 10, 'timeBased'),
    ('speed_demon_medium', 'Speed Demon - Medium', 'Complete Medium under 5 minutes', '🚀', 300, 50, 25, 'timeBased'),
    ('hard_winner', 'Rising Expert', 'Win your first Hard game', '📈', 1, 40, 20, 'difficultyBased'),
    ('expert_winner', 'Expert Achiever', 'Win your first Expert game', '🎓', 1, 75, 40, 'difficultyBased'),
    ('evil_winner', 'Evil Conqueror', 'Win your first Evil game', '😈', 1, 100, 50, 'difficultyBased');

-- Function to update rankings on match completion
CREATE OR REPLACE FUNCTION update_rankings()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO rankings (user_id, all_time_score)
    VALUES (NEW.user_id, 0)
    ON CONFLICT (user_id) DO UPDATE SET
        all_time_score = rankings.all_time_score + NEW.xp_earned,
        updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to call update_rankings on match insert
CREATE TRIGGER update_rankings_trigger
    AFTER INSERT ON matches
    FOR EACH ROW EXECUTE FUNCTION update_rankings();

-- Function to update user stats on match completion
CREATE OR REPLACE FUNCTION update_user_stats()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE users SET
        games_played = games_played + 1,
        games_won = CASE WHEN TRUE THEN games_won + 1 ELSE games_won END,
        perfect_games = CASE WHEN NEW.is_perfect THEN perfect_games + 1 ELSE perfect_games END,
        coins = coins + NEW.coins_earned,
        updated_at = NOW()
    WHERE id = NEW.user_id;

    -- Update best times if applicable
    IF NEW.is_perfect THEN
        CASE NEW.difficulty
            WHEN 'Easy' THEN UPDATE users SET best_time_easy = LEAST(best_time_easy, NEW.time) WHERE id = NEW.user_id;
            WHEN 'Medium' THEN UPDATE users SET best_time_medium = LEAST(best_time_medium, NEW.time) WHERE id = NEW.user_id;
            WHEN 'Hard' THEN UPDATE users SET best_time_hard = LEAST(best_time_hard, NEW.time) WHERE id = NEW.user_id;
            WHEN 'Expert' THEN UPDATE users SET best_time_expert = LEAST(best_time_expert, NEW.time) WHERE id = NEW.user_id;
            WHEN 'Evil' THEN UPDATE users SET best_time_evil = LEAST(best_time_evil, NEW.time) WHERE id = NEW.user_id;
        END CASE;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for user stats update
CREATE TRIGGER update_user_stats_trigger
    AFTER INSERT ON matches
    FOR EACH ROW EXECUTE FUNCTION update_user_stats();

-- Function to handle XP and level up
CREATE OR REPLACE FUNCTION handle_xp_level()
RETURNS TRIGGER AS $$
DECLARE
    new_level INTEGER;
    xp_needed INTEGER;
BEGIN
    -- Calculate new level based on total XP
    new_level := (NEW.xp / 100) + 1;
    xp_needed := NEW.xp % 100;

    -- Update user level
    UPDATE users SET
        level = new_level,
        xp = xp_needed,
        updated_at = NOW()
    WHERE id = NEW.id;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for XP level handling
CREATE TRIGGER handle_xp_level_trigger
    AFTER UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION handle_xp_level();