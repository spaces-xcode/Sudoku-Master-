// Supabase Service Layer for Sudoku Master
import 'package:supabase_flutter/supabase_flutter.dart';
import '../constants/app_constants.dart';

class SupabaseService {
  static final SupabaseService _instance = SupabaseService._internal();
  factory SupabaseService() => _instance;
  SupabaseService._internal();

  late SupabaseClient _client;

  SupabaseClient get client => _client;

  Future<void> initialize() async {
    await Supabase.initialize(
      url: AppConstants.supabaseUrl,
      anonKey: AppConstants.supabaseAnonKey,
    );
    _client = Supabase.instance.client;
  }

  // Auth methods
  Future<AuthResponse> signUp(String email, String password) async {
    return await _client.auth.signUp(
      email: email,
      password: password,
    );
  }

  Future<AuthResponse> signIn(String email, String password) async {
    return await _client.auth.signInWithPassword(
      email: email,
      password: password,
    );
  }

  Future<AuthResponse> signInWithGoogle() async {
    return await _client.auth.signInWithIdToken(
      provider: OAuthProvider.google,
      idToken: '', // Will be filled by the Google Sign In package
    );
  }

  Future<void> signOut() async {
    await _client.auth.signOut();
  }

  User? get currentUser => _client.auth.currentUser;

  // Real-time subscriptions
  void subscribeToLeaderboard(void Function(PostgresChangeEvent) onChange) {
    _client.channel('leaderboard_changes')
        .on(
          PostgresChangeEvent.all,
          ChannelFilter(table: 'rankings'),
          onChange,
        )
        .subscribe();
  }

  void subscribeToChallenges(void Function(PostgresChangeEvent) onChange, String userId) {
    _client.channel('challenge_$userId')
        .on(
          PostgresChangeEvent.insert,
          ChannelFilter(table: 'challenges', filter: 'receiver_id=eq.$userId'),
          onChange,
        )
        .subscribe();
  }
}