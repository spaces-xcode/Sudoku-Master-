// User Repository for Sudoku Master
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/supabase_service.dart';
import '../models/user_model.dart';

class UserRepository {
  final SupabaseService _supabase = SupabaseService();

  Future<UserModel?> getUser(String odId) async {
    final response = await _supabase.client
        .from('users')
        .select()
        .eq('id', odId)
        .single();

    if (response != null) {
      return UserModel.fromJson(response);
    }
    return null;
  }

  Future<UserModel?> getUserByEmail(String email) async {
    final response = await _supabase.client
        .from('users')
        .select()
        .eq('email', email)
        .single();

    if (response != null) {
      return UserModel.fromJson(response);
    }
    return null;
  }

  Future<void> createUser(UserModel user) async {
    await _supabase.client.from('users').insert(user.toJson());
  }

  Future<void> updateUser(UserModel user) async {
    await _supabase.client
        .from('users')
        .update(user.toJson())
        .eq('id', user.id);
  }

  Future<void> updateUserStats({
    required String odId,
    int? xp,
    int? level,
    int? coins,
    int? gamesPlayed,
    int? gamesWon,
    int? perfectGames,
    int? currentStreak,
    int? longestStreak,
  }) async {
    Map<String, dynamic> updates = {'updated_at': DateTime.now().toIso8601String()};

    if (xp != null) updates['xp'] = xp;
    if (level != null) updates['level'] = level;
    if (coins != null) updates['coins'] = coins;
    if (gamesPlayed != null) updates['games_played'] = gamesPlayed;
    if (gamesWon != null) updates['games_won'] = gamesWon;
    if (perfectGames != null) updates['perfect_games'] = perfectGames;
    if (currentStreak != null) updates['current_streak'] = currentStreak;
    if (longestStreak != null) updates['longest_streak'] = longestStreak;

    await _supabase.client
        .from('users')
        .update(updates)
        .eq('id', odId);
  }

  Future<void> updateUsername(String odId, String username) async {
    await _supabase.client
        .from('users')
        .update({
          'username': username,
          'updated_at': DateTime.now().toIso8601String(),
        })
        .eq('id', odId);
  }

  Future<void> updateAvatar(String odId, String avatarUrl) async {
    await _supabase.client
        .from('users')
        .update({
          'avatar_url': avatarUrl,
          'updated_at': DateTime.now().toIso8601String(),
        })
        .eq('id', odId);
  }

  Future<void> updateLastDailyChallenge(String odId) async {
    await _supabase.client
        .from('users')
        .update({
          'last_daily_challenge': DateTime.now().toIso8601String(),
          'updated_at': DateTime.now().toIso8601String(),
        })
        .eq('id', odId);
  }

  Stream<UserModel> watchUser(String odId) {
    return _supabase.client
        .from('users')
        .stream(primaryKey: ['id'])
        .eq('id', odId)
        .map((event) => UserModel.fromJson(event.first));
  }
}