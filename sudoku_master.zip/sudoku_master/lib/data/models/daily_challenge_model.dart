// Daily Challenge Model for Sudoku Master
import 'package:equatable/equatable.dart';

class DailyChallengeModel extends Equatable {
  final String id;
  final String date;
  final String difficulty;
  final List<List<int>> puzzle;
  final List<List<int>> solution;
  final int totalXpReward;
  final int coinReward;
  final int badgeId;
  final bool isCompleted;
  final int? bestTime;
  final bool isPerfect;

  const DailyChallengeModel({
    required this.id,
    required this.date,
    required this.difficulty,
    required this.puzzle,
    required this.solution,
    required this.totalXpReward,
    required this.coinReward,
    required this.badgeId,
    this.isCompleted = false,
    this.bestTime,
    this.isPerfect = false,
  });

  factory DailyChallengeModel.fromJson(Map<String, dynamic> json) {
    return DailyChallengeModel(
      id: json['id'] as String,
      date: json['date'] as String,
      difficulty: json['difficulty'] as String,
      puzzle: (json['puzzle'] as List)
          .map((row) => (row as List).map((e) => e as int).toList())
          .toList(),
      solution: (json['solution'] as List)
          .map((row) => (row as List).map((e) => e as int).toList())
          .toList(),
      totalXpReward: json['total_xp_reward'] as int,
      coinReward: json['coin_reward'] as int,
      badgeId: json['badge_id'] as int,
      isCompleted: json['is_completed'] as bool? ?? false,
      bestTime: json['best_time'] as int?,
      isPerfect: json['is_perfect'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'date': date,
      'difficulty': difficulty,
      'puzzle': puzzle,
      'solution': solution,
      'total_xp_reward': totalXpReward,
      'coin_reward': coinReward,
      'badge_id': badgeId,
      'is_completed': isCompleted,
      'best_time': bestTime,
      'is_perfect': isPerfect,
    };
  }

  DailyChallengeModel copyWith({
    String? id,
    String? date,
    String? difficulty,
    List<List<int>>? puzzle,
    List<List<int>>? solution,
    int? totalXpReward,
    int? coinReward,
    int? badgeId,
    bool? isCompleted,
    int? bestTime,
    bool? isPerfect,
  }) {
    return DailyChallengeModel(
      id: id ?? this.id,
      date: date ?? this.date,
      difficulty: difficulty ?? this.difficulty,
      puzzle: puzzle ?? this.puzzle,
      solution: solution ?? this.solution,
      totalXpReward: totalXpReward ?? this.totalXpReward,
      coinReward: coinReward ?? this.coinReward,
      badgeId: badgeId ?? this.badgeId,
      isCompleted: isCompleted ?? this.isCompleted,
      bestTime: bestTime ?? this.bestTime,
      isPerfect: isPerfect ?? this.isPerfect,
    );
  }

  @override
  List<Object?> get props => [
        id,
        date,
        difficulty,
        puzzle,
        solution,
        totalXpReward,
        coinReward,
        badgeId,
        isCompleted,
        bestTime,
        isPerfect,
      ];
}

class ChallengeModel extends Equatable {
  final String id;
  final String senderId;
  final String senderName;
  final String receiverId;
  final String difficulty;
  final List<List<int>> puzzle;
  final bool isCompleted;
  final int? senderTime;
  final int? receiverTime;
  final DateTime createdAt;
  final DateTime? completedAt;

  const ChallengeModel({
    required this.id,
    required this.senderId,
    required this.senderName,
    required this.receiverId,
    required this.difficulty,
    required this.puzzle,
    this.isCompleted = false,
    this.senderTime,
    this.receiverTime,
    required this.createdAt,
    this.completedAt,
  });

  factory ChallengeModel.fromJson(Map<String, dynamic> json) {
    return ChallengeModel(
      id: json['id'] as String,
      senderId: json['sender_id'] as String,
      senderName: json['sender_name'] as String,
      receiverId: json['receiver_id'] as String,
      difficulty: json['difficulty'] as String,
      puzzle: (json['puzzle'] as List)
          .map((row) => (row as List).map((e) => e as int).toList())
          .toList(),
      isCompleted: json['is_completed'] as bool? ?? false,
      senderTime: json['sender_time'] as int?,
      receiverTime: json['receiver_time'] as int?,
      createdAt: DateTime.parse(json['created_at'] as String),
      completedAt: json['completed_at'] != null
          ? DateTime.parse(json['completed_at'] as String)
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'sender_id': senderId,
      'sender_name': senderName,
      'receiver_id': receiverId,
      'difficulty': difficulty,
      'puzzle': puzzle,
      'is_completed': isCompleted,
      'sender_time': senderTime,
      'receiver_time': receiverTime,
      'created_at': createdAt.toIso8601String(),
      'completed_at': completedAt?.toIso8601String(),
    };
  }

  @override
  List<Object?> get props => [
        id,
        senderId,
        senderName,
        receiverId,
        difficulty,
        puzzle,
        isCompleted,
        senderTime,
        receiverTime,
        createdAt,
        completedAt,
      ];
}