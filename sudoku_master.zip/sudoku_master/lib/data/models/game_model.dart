// Game Model for Sudoku Master
import 'package:equatable/equatable.dart';
import '../../core/utils/sudoku_logic.dart';

class GameModel extends Equatable {
  final String id;
  final String odId;
  final String difficulty;
  final List<List<int>> initialBoard;
  final List<List<int>> currentBoard;
  final List<List<List<int>>> pencilMarks;
  final int mistakes;
  final int hintsUsed;
  final int elapsedTime;
  final bool isPaused;
  final bool isComplete;
  final bool isPerfect;
  final DateTime startedAt;
  final DateTime? completedAt;

  const GameModel({
    required this.id,
    required this.odId,
    required this.difficulty,
    required this.initialBoard,
    required this.currentBoard,
    required this.pencilMarks,
    this.mistakes = 0,
    this.hintsUsed = 0,
    this.elapsedTime = 0,
    this.isPaused = false,
    this.isComplete = false,
    this.isPerfect = false,
    required this.startedAt,
    this.completedAt,
  });

  factory GameModel.fromJson(Map<String, dynamic> json) {
    return GameModel(
      id: json['id'] as String,
      odId: json['user_id'] as String,
      difficulty: json['difficulty'] as String,
      initialBoard: (json['initial_board'] as List)
          .map((row) => (row as List).map((e) => e as int).toList())
          .toList(),
      currentBoard: (json['current_board'] as List)
          .map((row) => (row as List).map((e) => e as int).toList())
          .toList(),
      pencilMarks: (json['pencil_marks'] as List)
          .map((row) => (row as List)
              .map((cell) => (cell as List).map((e) => e as int).toList())
              .toList())
          .toList(),
      mistakes: json['mistakes'] as int? ?? 0,
      hintsUsed: json['hints_used'] as int? ?? 0,
      elapsedTime: json['elapsed_time'] as int? ?? 0,
      isPaused: json['is_paused'] as bool? ?? false,
      isComplete: json['is_complete'] as bool? ?? false,
      isPerfect: json['is_perfect'] as bool? ?? false,
      startedAt: DateTime.parse(json['started_at'] as String),
      completedAt: json['completed_at'] != null
          ? DateTime.parse(json['completed_at'] as String)
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'user_id': odId,
      'difficulty': difficulty,
      'initial_board': initialBoard,
      'current_board': currentBoard,
      'pencil_marks': pencilMarks,
      'mistakes': mistakes,
      'hints_used': hintsUsed,
      'elapsed_time': elapsedTime,
      'is_paused': isPaused,
      'is_complete': isComplete,
      'is_perfect': isPerfect,
      'started_at': startedAt.toIso8601String(),
      'completed_at': completedAt?.toIso8601String(),
    };
  }

  GameModel copyWith({
    String? id,
    String? odId,
    String? difficulty,
    List<List<int>>? initialBoard,
    List<List<int>>? currentBoard,
    List<List<List<int>>>? pencilMarks,
    int? mistakes,
    int? hintsUsed,
    int? elapsedTime,
    bool? isPaused,
    bool? isComplete,
    bool? isPerfect,
    DateTime? startedAt,
    DateTime? completedAt,
  }) {
    return GameModel(
      id: id ?? this.id,
      odId: odId ?? this.odId,
      difficulty: difficulty ?? this.difficulty,
      initialBoard: initialBoard ?? this.initialBoard,
      currentBoard: currentBoard ?? this.currentBoard,
      pencilMarks: pencilMarks ?? this.pencilMarks,
      mistakes: mistakes ?? this.mistakes,
      hintsUsed: hintsUsed ?? this.hintsUsed,
      elapsedTime: elapsedTime ?? this.elapsedTime,
      isPaused: isPaused ?? this.isPaused,
      isComplete: isComplete ?? this.isComplete,
      isPerfect: isPerfect ?? this.isPerfect,
      startedAt: startedAt ?? this.startedAt,
      completedAt: completedAt ?? this.completedAt,
    );
  }

  @override
  List<Object?> get props => [
        id,
        odId,
        difficulty,
        initialBoard,
        currentBoard,
        pencilMarks,
        mistakes,
        hintsUsed,
        elapsedTime,
        isPaused,
        isComplete,
        isPerfect,
        startedAt,
        completedAt,
      ];
}

class MatchResult extends Equatable {
  final String id;
  final String odId;
  final String difficulty;
  final int time;
  final int mistakes;
  final int hintsUsed;
  final bool isPerfect;
  final int xpEarned;
  final int coinsEarned;
  final DateTime completedAt;

  const MatchResult({
    required this.id,
    required this.odId,
    required this.difficulty,
    required this.time,
    required this.mistakes,
    required this.hintsUsed,
    required this.isPerfect,
    required this.xpEarned,
    required this.coinsEarned,
    required this.completedAt,
  });

  factory MatchResult.fromJson(Map<String, dynamic> json) {
    return MatchResult(
      id: json['id'] as String,
      odId: json['user_id'] as String,
      difficulty: json['difficulty'] as String,
      time: json['time'] as int,
      mistakes: json['mistakes'] as int,
      hintsUsed: json['hints_used'] as int,
      isPerfect: json['is_perfect'] as bool,
      xpEarned: json['xp_earned'] as int,
      coinsEarned: json['coins_earned'] as int,
      completedAt: DateTime.parse(json['completed_at'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'user_id': odId,
      'difficulty': difficulty,
      'time': time,
      'mistakes': mistakes,
      'hints_used': hintsUsed,
      'is_perfect': isPerfect,
      'xp_earned': xpEarned,
      'coins_earned': coinsEarned,
      'completed_at': completedAt.toIso8601String(),
    };
  }

  @override
  List<Object?> get props => [
        id,
        odId,
        difficulty,
        time,
        mistakes,
        hintsUsed,
        isPerfect,
        xpEarned,
        coinsEarned,
        completedAt,
      ];
}