// User Model for Sudoku Master
import 'package:equatable/equatable.dart';

class UserModel extends Equatable {
  final String id;
  final String email;
  final String? username;
  final String? avatarUrl;
  final String? country;
  final int level;
  final int xp;
  final int coins;
  final int gamesPlayed;
  final int gamesWon;
  final int perfectGames;
  final int bestTimeEasy;
  final int bestTimeMedium;
  final int bestTimeHard;
  final int bestTimeExpert;
  final int bestTimeEvil;
  final int currentStreak;
  final int longestStreak;
  final DateTime? lastDailyChallenge;
  final bool isPremium;
  final DateTime createdAt;
  final DateTime updatedAt;

  const UserModel({
    required this.id,
    required this.email,
    this.username,
    this.avatarUrl,
    this.country,
    this.level = 1,
    this.xp = 0,
    this.coins = 0,
    this.gamesPlayed = 0,
    this.gamesWon = 0,
    this.perfectGames = 0,
    this.bestTimeEasy = 0,
    this.bestTimeMedium = 0,
    this.bestTimeHard = 0,
    this.bestTimeExpert = 0,
    this.bestTimeEvil = 0,
    this.currentStreak = 0,
    this.longestStreak = 0,
    this.lastDailyChallenge,
    this.isPremium = false,
    required this.createdAt,
    required this.updatedAt,
  });

  int get totalXp => (level - 1) * 100 + xp;

  double get winRate => gamesPlayed > 0 ? gamesWon / gamesPlayed : 0.0;

  String get tierName {
    if (level < 20) return 'Beginner';
    if (level < 40) return 'Intermediate';
    if (level < 60) return 'Expert';
    if (level < 80) return 'Master';
    return 'Grandmaster';
  }

  int get xpForNextLevel => 100 - xp;

  double get levelProgress => xp / 100;

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] as String,
      email: json['email'] as String,
      username: json['username'] as String?,
      avatarUrl: json['avatar_url'] as String?,
      country: json['country'] as String?,
      level: json['level'] as int? ?? 1,
      xp: json['xp'] as int? ?? 0,
      coins: json['coins'] as int? ?? 0,
      gamesPlayed: json['games_played'] as int? ?? 0,
      gamesWon: json['games_won'] as int? ?? 0,
      perfectGames: json['perfect_games'] as int? ?? 0,
      bestTimeEasy: json['best_time_easy'] as int? ?? 0,
      bestTimeMedium: json['best_time_medium'] as int? ?? 0,
      bestTimeHard: json['best_time_hard'] as int? ?? 0,
      bestTimeExpert: json['best_time_expert'] as int? ?? 0,
      bestTimeEvil: json['best_time_evil'] as int? ?? 0,
      currentStreak: json['current_streak'] as int? ?? 0,
      longestStreak: json['longest_streak'] as int? ?? 0,
      lastDailyChallenge: json['last_daily_challenge'] != null
          ? DateTime.parse(json['last_daily_challenge'] as String)
          : null,
      isPremium: json['is_premium'] as bool? ?? false,
      createdAt: DateTime.parse(json['created_at'] as String),
      updatedAt: DateTime.parse(json['updated_at'] as String),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'email': email,
      'username': username,
      'avatar_url': avatarUrl,
      'country': country,
      'level': level,
      'xp': xp,
      'coins': coins,
      'games_played': gamesPlayed,
      'games_won': gamesWon,
      'perfect_games': perfectGames,
      'best_time_easy': bestTimeEasy,
      'best_time_medium': bestTimeMedium,
      'best_time_hard': bestTimeHard,
      'best_time_expert': bestTimeExpert,
      'best_time_evil': bestTimeEvil,
      'current_streak': currentStreak,
      'longest_streak': longestStreak,
      'last_daily_challenge': lastDailyChallenge?.toIso8601String(),
      'is_premium': isPremium,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
  }

  UserModel copyWith({
    String? id,
    String? email,
    String? username,
    String? avatarUrl,
    String? country,
    int? level,
    int? xp,
    int? coins,
    int? gamesPlayed,
    int? gamesWon,
    int? perfectGames,
    int? bestTimeEasy,
    int? bestTimeMedium,
    int? bestTimeHard,
    int? bestTimeExpert,
    int? bestTimeEvil,
    int? currentStreak,
    int? longestStreak,
    DateTime? lastDailyChallenge,
    bool? isPremium,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return UserModel(
      id: id ?? this.id,
      email: email ?? this.email,
      username: username ?? this.username,
      avatarUrl: avatarUrl ?? this.avatarUrl,
      country: country ?? this.country,
      level: level ?? this.level,
      xp: xp ?? this.xp,
      coins: coins ?? this.coins,
      gamesPlayed: gamesPlayed ?? this.gamesPlayed,
      gamesWon: gamesWon ?? this.gamesWon,
      perfectGames: perfectGames ?? this.perfectGames,
      bestTimeEasy: bestTimeEasy ?? this.bestTimeEasy,
      bestTimeMedium: bestTimeMedium ?? this.bestTimeMedium,
      bestTimeHard: bestTimeHard ?? this.bestTimeHard,
      bestTimeExpert: bestTimeExpert ?? this.bestTimeExpert,
      bestTimeEvil: bestTimeEvil ?? this.bestTimeEvil,
      currentStreak: currentStreak ?? this.currentStreak,
      longestStreak: longestStreak ?? this.longestStreak,
      lastDailyChallenge: lastDailyChallenge ?? this.lastDailyChallenge,
      isPremium: isPremium ?? this.isPremium,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  @override
  List<Object?> get props => [
        id,
        email,
        username,
        avatarUrl,
        country,
        level,
        xp,
        coins,
        gamesPlayed,
        gamesWon,
        perfectGames,
        bestTimeEasy,
        bestTimeMedium,
        bestTimeHard,
        bestTimeExpert,
        bestTimeEvil,
        currentStreak,
        longestStreak,
        lastDailyChallenge,
        isPremium,
        createdAt,
        updatedAt,
      ];
}