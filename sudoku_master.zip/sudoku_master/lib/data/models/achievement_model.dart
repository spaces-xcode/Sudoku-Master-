// Achievement Model for Sudoku Master
import 'package:equatable/equatable.dart';

enum AchievementType {
  gamesPlayed,
  perfectGames,
  streaks,
  timeBased,
  difficultyBased,
}

class AchievementModel extends Equatable {
  final String id;
  final String name;
  final String description;
  final String iconName;
  final int targetValue;
  final int xpReward;
  final int coinReward;
  final AchievementType type;
  final bool isUnlocked;
  final DateTime? unlockedAt;

  const AchievementModel({
    required this.id,
    required this.name,
    required this.description,
    required this.iconName,
    required this.targetValue,
    required this.xpReward,
    required this.coinReward,
    required this.type,
    this.isUnlocked = false,
    this.unlockedAt,
  });

  factory AchievementModel.fromJson(Map<String, dynamic> json) {
    return AchievementModel(
      id: json['id'] as String,
      name: json['name'] as String,
      description: json['description'] as String,
      iconName: json['icon_name'] as String,
      targetValue: json['target_value'] as int,
      xpReward: json['xp_reward'] as int,
      coinReward: json['coin_reward'] as int,
      type: AchievementType.values.firstWhere(
        (e) => e.name == json['type'],
        orElse: () => AchievementType.gamesPlayed,
      ),
      isUnlocked: json['is_unlocked'] as bool? ?? false,
      unlockedAt: json['unlocked_at'] != null
          ? DateTime.parse(json['unlocked_at'] as String)
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'icon_name': iconName,
      'target_value': targetValue,
      'xp_reward': xpReward,
      'coin_reward': coinReward,
      'type': type.name,
      'is_unlocked': isUnlocked,
      'unlocked_at': unlockedAt?.toIso8601String(),
    };
  }

  AchievementModel copyWith({
    String? id,
    String? name,
    String? description,
    String? iconName,
    int? targetValue,
    int? xpReward,
    int? coinReward,
    AchievementType? type,
    bool? isUnlocked,
    DateTime? unlockedAt,
  }) {
    return AchievementModel(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      iconName: iconName ?? this.iconName,
      targetValue: targetValue ?? this.targetValue,
      xpReward: xpReward ?? this.xpReward,
      coinReward: coinReward ?? this.coinReward,
      type: type ?? this.type,
      isUnlocked: isUnlocked ?? this.isUnlocked,
      unlockedAt: unlockedAt ?? this.unlockedAt,
    );
  }

  @override
  List<Object?> get props => [
        id,
        name,
        description,
        iconName,
        targetValue,
        xpReward,
        coinReward,
        type,
        isUnlocked,
        unlockedAt,
      ];
}

class UserAchievement extends Equatable {
  final String odId;
  final String achievementId;
  final int currentProgress;
  final bool isUnlocked;
  final DateTime? unlockedAt;

  const UserAchievement({
    required this.odId,
    required this.achievementId,
    this.currentProgress = 0,
    this.isUnlocked = false,
    this.unlockedAt,
  });

  factory UserAchievement.fromJson(Map<String, dynamic> json) {
    return UserAchievement(
      odId: json['user_id'] as String,
      achievementId: json['achievement_id'] as String,
      currentProgress: json['current_progress'] as int? ?? 0,
      isUnlocked: json['is_unlocked'] as bool? ?? false,
      unlockedAt: json['unlocked_at'] != null
          ? DateTime.parse(json['unlocked_at'] as String)
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'user_id': odId,
      'achievement_id': achievementId,
      'current_progress': currentProgress,
      'is_unlocked': isUnlocked,
      'unlocked_at': unlockedAt?.toIso8601String(),
    };
  }

  @override
  List<Object?> get props => [
        odId,
        achievementId,
        currentProgress,
        isUnlocked,
        unlockedAt,
      ];
}

// Predefined Achievements
class PredefinedAchievements {
  static List<AchievementModel> get all => [
    const AchievementModel(
      id: 'first_game',
      name: 'First Steps',
      description: 'Complete your first game',
      iconName: '🎮',
      targetValue: 1,
      xpReward: 10,
      coinReward: 5,
      type: AchievementType.gamesPlayed,
    ),
    const AchievementModel(
      id: 'games_10',
      name: 'Getting Started',
      description: 'Complete 10 games',
      iconName: '🎯',
      targetValue: 10,
      xpReward: 25,
      coinReward: 10,
      type: AchievementType.gamesPlayed,
    ),
    const AchievementModel(
      id: 'games_50',
      name: 'Dedicated Player',
      description: 'Complete 50 games',
      iconName: '⭐',
      targetValue: 50,
      xpReward: 50,
      coinReward: 25,
      type: AchievementType.gamesPlayed,
    ),
    const AchievementModel(
      id: 'games_100',
      name: 'Sudoku Enthusiast',
      description: 'Complete 100 games',
      iconName: '🏆',
      targetValue: 100,
      xpReward: 100,
      coinReward: 50,
      type: AchievementType.gamesPlayed,
    ),
    const AchievementModel(
      id: 'games_500',
      name: 'Sudoku Master',
      description: 'Complete 500 games',
      iconName: '👑',
      targetValue: 500,
      xpReward: 250,
      coinReward: 100,
      type: AchievementType.gamesPlayed,
    ),
    const AchievementModel(
      id: 'perfect_5',
      name: 'Perfect Start',
      description: 'Win 5 perfect games',
      iconName: '✨',
      targetValue: 5,
      xpReward: 30,
      coinReward: 15,
      type: AchievementType.perfectGames,
    ),
    const AchievementModel(
      id: 'perfect_25',
      name: 'Perfectionist',
      description: 'Win 25 perfect games',
      iconName: '💎',
      targetValue: 25,
      xpReward: 75,
      coinReward: 40,
      type: AchievementType.perfectGames,
    ),
    const AchievementModel(
      id: 'perfect_100',
      name: 'Flawless',
      description: 'Win 100 perfect games',
      iconName: '💫',
      targetValue: 100,
      xpReward: 200,
      coinReward: 100,
      type: AchievementType.perfectGames,
    ),
    const AchievementModel(
      id: 'streak_3',
      name: 'On Fire',
      description: 'Complete 3 day streak',
      iconName: '🔥',
      targetValue: 3,
      xpReward: 20,
      coinReward: 10,
      type: AchievementType.streaks,
    ),
    const AchievementModel(
      id: 'streak_7',
      name: 'Week Warrior',
      description: 'Complete 7 day streak',
      iconName: '📅',
      targetValue: 7,
      xpReward: 50,
      coinReward: 25,
      type: AchievementType.streaks,
    ),
    const AchievementModel(
      id: 'streak_30',
      name: 'Monthly Champion',
      description: 'Complete 30 day streak',
      iconName: '🏅',
      targetValue: 30,
      xpReward: 150,
      coinReward: 75,
      type: AchievementType.streaks,
    ),
    const AchievementModel(
      id: 'speed_demon_easy',
      name: 'Speed Demon - Easy',
      description: 'Complete Easy under 3 minutes',
      iconName: '⚡',
      targetValue: 180,
      xpReward: 25,
      coinReward: 10,
      type: AchievementType.timeBased,
    ),
    const AchievementModel(
      id: 'speed_demon_medium',
      name: 'Speed Demon - Medium',
      description: 'Complete Medium under 5 minutes',
      iconName: '🚀',
      targetValue: 300,
      xpReward: 50,
      coinReward: 25,
      type: AchievementType.timeBased,
    ),
    const AchievementModel(
      id: 'hard_winner',
      name: 'Rising Expert',
      description: 'Win your first Hard game',
      iconName: '📈',
      targetValue: 1,
      xpReward: 40,
      coinReward: 20,
      type: AchievementType.difficultyBased,
    ),
    const AchievementModel(
      id: 'expert_winner',
      name: 'Expert Achiever',
      description: 'Win your first Expert game',
      iconName: '🎓',
      targetValue: 1,
      xpReward: 75,
      coinReward: 40,
      type: AchievementType.difficultyBased,
    ),
    const AchievementModel(
      id: 'evil_winner',
      name: 'Evil Conqueror',
      description: 'Win your first Evil game',
      iconName: '😈',
      targetValue: 1,
      xpReward: 100,
      coinReward: 50,
      type: AchievementType.difficultyBased,
    ),
  ];
}