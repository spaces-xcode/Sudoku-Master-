// Ranking Model for Sudoku Master
import 'package:equatable/equatable.dart';

class RankingModel extends Equatable {
  final String odId;
  final String username;
  final String? avatarUrl;
  final int level;
  final int totalXp;
  final int gamesPlayed;
  final int gamesWon;
  final int weeklyScore;
  final int monthlyScore;
  final int allTimeScore;
  final int rank;
  final int weeklyRank;
  final int monthlyRank;

  const RankingModel({
    required this.odId,
    required this.username,
    this.avatarUrl,
    required this.level,
    required this.totalXp,
    required this.gamesPlayed,
    required this.gamesWon,
    required this.weeklyScore,
    required this.monthlyScore,
    required this.allTimeScore,
    this.rank = 0,
    this.weeklyRank = 0,
    this.monthlyRank = 0,
  });

  factory RankingModel.fromJson(Map<String, dynamic> json) {
    return RankingModel(
      odId: json['user_id'] as String,
      username: json['username'] as String,
      avatarUrl: json['avatar_url'] as String?,
      level: json['level'] as int,
      totalXp: json['total_xp'] as int,
      gamesPlayed: json['games_played'] as int,
      gamesWon: json['games_won'] as int,
      weeklyScore: json['weekly_score'] as int? ?? 0,
      monthlyScore: json['monthly_score'] as int? ?? 0,
      allTimeScore: json['all_time_score'] as int? ?? 0,
      rank: json['rank'] as int? ?? 0,
      weeklyRank: json['weekly_rank'] as int? ?? 0,
      monthlyRank: json['monthly_rank'] as int? ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'user_id': odId,
      'username': username,
      'avatar_url': avatarUrl,
      'level': level,
      'total_xp': totalXp,
      'games_played': gamesPlayed,
      'games_won': gamesWon,
      'weekly_score': weeklyScore,
      'monthly_score': monthlyScore,
      'all_time_score': allTimeScore,
      'rank': rank,
      'weekly_rank': weeklyRank,
      'monthly_rank': monthlyRank,
    };
  }

  @override
  List<Object?> get props => [
        odId,
        username,
        avatarUrl,
        level,
        totalXp,
        gamesPlayed,
        gamesWon,
        weeklyScore,
        monthlyScore,
        allTimeScore,
        rank,
        weeklyRank,
        monthlyRank,
      ];
}

class TournamentModel extends Equatable {
  final String id;
  final String name;
  final String description;
  final DateTime startDate;
  final DateTime endDate;
  final String difficulty;
  final int participantCount;
  final int prizePool;
  final bool isActive;
  final int? userRank;
  final int? userScore;

  const TournamentModel({
    required this.id,
    required this.name,
    required this.description,
    required this.startDate,
    required this.endDate,
    required this.difficulty,
    required this.participantCount,
    required this.prizePool,
    this.isActive = false,
    this.userRank,
    this.userScore,
  });

  factory TournamentModel.fromJson(Map<String, dynamic> json) {
    return TournamentModel(
      id: json['id'] as String,
      name: json['name'] as String,
      description: json['description'] as String,
      startDate: DateTime.parse(json['start_date'] as String),
      endDate: DateTime.parse(json['end_date'] as String),
      difficulty: json['difficulty'] as String,
      participantCount: json['participant_count'] as int,
      prizePool: json['prize_pool'] as int,
      isActive: json['is_active'] as bool? ?? false,
      userRank: json['user_rank'] as int?,
      userScore: json['user_score'] as int?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'start_date': startDate.toIso8601String(),
      'end_date': endDate.toIso8601String(),
      'difficulty': difficulty,
      'participant_count': participantCount,
      'prize_pool': prizePool,
      'is_active': isActive,
      'user_rank': userRank,
      'user_score': userScore,
    };
  }

  @override
  List<Object?> get props => [
        id,
        name,
        description,
        startDate,
        endDate,
        difficulty,
        participantCount,
        prizePool,
        isActive,
        userRank,
        userScore,
      ];
}