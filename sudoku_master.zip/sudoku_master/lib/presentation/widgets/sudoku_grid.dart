// Sudoku Grid Widget
import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/sudoku_logic.dart';

class SudokuGrid extends StatelessWidget {
  final SudokuBoard board;
  final int? selectedRow;
  final int? selectedCol;
  final bool highlightNumbers;
  final bool highlightRowCol;
  final ValueChanged<int>? onCellTap;

  const SudokuGrid({
    super.key,
    required this.board,
    this.selectedRow,
    this.selectedCol,
    this.highlightNumbers = true,
    this.highlightRowCol = true,
    this.onCellTap,
  });

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1,
      child: Container(
        decoration: BoxDecoration(
          color: AppTheme.surfaceLight,
          borderRadius: BorderRadius.circular(16),
          boxShadow: AppTheme.mediumShadow,
        ),
        padding: const EdgeInsets.all(8),
        child: GridView.builder(
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 9,
          ),
          itemCount: 81,
          itemBuilder: (context, index) {
            final row = index ~/ 9;
            final col = index % 9;
            return _SudokuCell(
              cell: board.getCell(row, col),
              isSelected: selectedRow == row && selectedCol == col,
              highlightNumbers: highlightNumbers,
              highlightRowCol: highlightRowCol,
              selectedValue: selectedRow != null && selectedCol != null
                  ? board.getCell(selectedRow!, selectedCol!).value
                  : null,
              onTap: () => onCellTap?.call(index),
            );
          },
        ),
      ),
    );
  }
}

class _SudokuCell extends StatelessWidget {
  final SudokuCell cell;
  final bool isSelected;
  final bool highlightNumbers;
  final bool highlightRowCol;
  final int? selectedValue;
  final VoidCallback onTap;

  const _SudokuCell({
    required this.cell,
    required this.isSelected,
    required this.highlightNumbers,
    required this.highlightRowCol,
    required this.selectedValue,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    // Determine if cell should be highlighted
    final isHighlighted = _isCellHighlighted();

    // Determine border radius
    final borderRadius = _getBorderRadius();

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        margin: const EdgeInsets.all(1),
        decoration: BoxDecoration(
          color: _getCellColor(),
          borderRadius: borderRadius,
        ),
        child: Center(
          child: cell.value != 0
              ? _buildNumber(cell.value)
              : _buildPencilMarks(),
        ),
      ),
    );
  }

  bool _isCellHighlighted() {
    if (!highlightNumbers || selectedValue == null || selectedValue == 0) {
      return false;
    }

    if (cell.value == selectedValue) {
      return true;
    }

    return false;
  }

  bool _isRowColHighlighted() {
    if (!highlightRowCol) return false;
    if (selectedRow == null || selectedCol == null) return false;

    return cell.row == selectedRow || cell.col == selectedCol;
  }

  BorderRadius _getBorderRadius() {
    const radius = 4.0;
    const halfCell = 4.5;

    double topLeft = 0;
    double topRight = 0;
    double bottomLeft = 0;
    double bottomRight = 0;

    if (cell.row == 0 && cell.col == 0) topLeft = radius;
    if (cell.row == 0 && cell.col == 8) topRight = radius;
    if (cell.row == 8 && cell.col == 0) bottomLeft = radius;
    if (cell.row == 8 && cell.col == 8) bottomRight = radius;

    // Box boundaries
    if (cell.row % 3 == 0 && cell.col % 3 == 0 && cell.row > 0) topLeft = radius;
    if (cell.row % 3 == 0 && cell.col % 3 == 2 && cell.row > 0) topRight = radius;
    if (cell.row % 3 == 2 && cell.col % 3 == 0 && cell.row < 8) bottomLeft = radius;
    if (cell.row % 3 == 2 && cell.col % 3 == 2 && cell.row < 8) bottomRight = radius;

    return BorderRadius.only(
      topLeft: Radius.circular(topLeft),
      topRight: Radius.circular(topRight),
      bottomLeft: Radius.circular(bottomLeft),
      bottomRight: Radius.circular(bottomRight),
    );
  }

  Color _getCellColor() {
    if (isSelected) {
      return AppTheme.primaryBlue.withOpacity(0.3);
    }

    if (_isRowColHighlighted() && !_isCellHighlighted()) {
      return AppTheme.primaryBlue.withOpacity(0.1);
    }

    if (_isCellHighlighted()) {
      return AppTheme.primaryBlue.withOpacity(0.2);
    }

    return Colors.transparent;
  }

  Widget _buildNumber(int value) {
    final color = cell.isFixed
        ? AppTheme.textPrimary
        : cell.isError
            ? AppTheme.error
            : AppTheme.primaryBlue;

    return Text(
      '$value',
      style: TextStyle(
        fontSize: 24,
        fontWeight: cell.isFixed ? FontWeight.w600 : FontWeight.w500,
        color: color,
      ),
    );
  }

  Widget _buildPencilMarks() {
    if (cell.pencilMarks.isEmpty) {
      return const SizedBox();
    }

    return Wrap(
      alignment: WrapAlignment.center,
      children: List.generate(9, (index) {
        final number = index + 1;
        final hasMark = cell.pencilMarks.contains(number);
        return SizedBox(
          width: 11,
          height: 11,
          child: Text(
            hasMark ? '$number' : '',
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontSize: 8,
              color: AppTheme.textSecondary,
              fontWeight: FontWeight.w500,
            ),
          ),
        );
      }),
    );
  }
}

// Number Pad
class NumberPad extends StatelessWidget {
  final Function(int) onNumberTap;
  final VoidCallback? onUndoTap;
  final VoidCallback? onEraseTap;
  final VoidCallback? onHintTap;
  final VoidCallback? onPencilTap;
  final bool pencilMode;

  const NumberPad({
    super.key,
    required this.onNumberTap,
    this.onUndoTap,
    this.onEraseTap,
    this.onHintTap,
    this.onPencilTap,
    this.pencilMode = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.surfaceLight,
        borderRadius: BorderRadius.circular(20),
        boxShadow: AppTheme.softShadow,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Action buttons row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _ActionButton(
                icon: Icons.undo_rounded,
                onTap: onUndoTap ?? () {},
                color: AppTheme.textSecondary,
              ),
              _ActionButton(
                icon: Icons.backspace_rounded,
                onTap: onEraseTap ?? () {},
                color: AppTheme.error,
              ),
              _ActionButton(
                icon: Icons.edit_rounded,
                onTap: onPencilTap ?? () {},
                color: pencilMode ? AppTheme.primaryBlue : AppTheme.textSecondary,
                isActive: pencilMode,
              ),
              _ActionButton(
                icon: Icons.lightbulb_outline_rounded,
                onTap: onHintTap ?? () {},
                color: AppTheme.warning,
              ),
            ],
          ),
          const SizedBox(height: 16),
          // Number buttons
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: List.generate(9, (index) {
              return _NumberButton(
                number: index + 1,
                onTap: () => onNumberTap(index + 1),
              );
            }),
          ),
        ],
      ),
    );
  }
}

class _NumberButton extends StatelessWidget {
  final int number;
  final VoidCallback onTap;

  const _NumberButton({
    required this.number,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 36,
        height: 48,
        decoration: BoxDecoration(
          color: AppTheme.primaryBlue.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Center(
          child: Text(
            '$number',
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w600,
              color: AppTheme.primaryBlue,
            ),
          ),
        ),
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final Color color;
  final bool isActive;

  const _ActionButton({
    required this.icon,
    required this.onTap,
    required this.color,
    this.isActive = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 48,
        height: 48,
        decoration: BoxDecoration(
          color: isActive ? color.withOpacity(0.2) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Center(
          child: Icon(
            icon,
            color: color,
            size: 24,
          ),
        ),
      ),
    );
  }
}

// Timer Display
class TimerDisplay extends StatelessWidget {
  final int seconds;

  const TimerDisplay({
    super.key,
    required this.seconds,
  });

  @override
  Widget build(BuildContext context) {
    final minutes = seconds ~/ 60;
    final secs = seconds % 60;
    final formattedTime = '${minutes.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: AppTheme.surfaceLight,
        borderRadius: BorderRadius.circular(12),
        boxShadow: AppTheme.softShadow,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(
            Icons.timer_outlined,
            color: AppTheme.textSecondary,
            size: 20,
          ),
          const SizedBox(width: 8),
          Text(
            formattedTime,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: AppTheme.textPrimary,
              fontFeatures: [FontFeature.tabularFigures()],
            ),
          ),
        ],
      ),
    );
  }
}

// Mistake Counter
class MistakeCounter extends StatelessWidget {
  final int mistakes;
  final int maxMistakes;

  const MistakeCounter({
    super.key,
    required this.mistakes,
    this.maxMistakes = 3,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: mistakes > 0 ? AppTheme.error.withOpacity(0.1) : AppTheme.surfaceLight,
        borderRadius: BorderRadius.circular(12),
        boxShadow: AppTheme.softShadow,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.error_outline_rounded,
            color: mistakes > 0 ? AppTheme.error : AppTheme.textSecondary,
            size: 20,
          ),
          const SizedBox(width: 8),
          Text(
            '$mistakes / $maxMistakes',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
              color: mistakes > 0 ? AppTheme.error : AppTheme.textPrimary,
            ),
          ),
        ],
      ),
    );
  }
}