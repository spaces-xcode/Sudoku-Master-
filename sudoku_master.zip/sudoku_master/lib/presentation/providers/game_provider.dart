// Game Provider for Sudoku Master
import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/utils/sudoku_logic.dart';
import '../../core/constants/app_constants.dart';
import '../../data/models/game_model.dart';
import '../../data/repositories/user_repository.dart';
import 'auth_provider.dart';

// Game State
class GameState {
  final SudokuBoard? board;
  final int? selectedRow;
  final int? selectedCol;
  final String difficulty;
  final int elapsedTime;
  final int mistakes;
  final bool isComplete;
  final bool isPaused;
  final bool showErrors;
  final bool highlightNumbers;
  final bool highlightRowCol;
  final List<GameAction> history;
  final int hintsUsed;

  const GameState({
    this.board,
    this.selectedRow,
    this.selectedCol,
    this.difficulty = 'Easy',
    this.elapsedTime = 0,
    this.mistakes = 0,
    this.isComplete = false,
    this.isPaused = false,
    this.showErrors = true,
    this.highlightNumbers = true,
    this.highlightRowCol = true,
    this.history = const [],
    this.hintsUsed = 0,
  });

  GameState copyWith({
    SudokuBoard? board,
    int? selectedRow,
    int? selectedCol,
    String? difficulty,
    int? elapsedTime,
    int? mistakes,
    bool? isComplete,
    bool? isPaused,
    bool? showErrors,
    bool? highlightNumbers,
    bool? highlightRowCol,
    List<GameAction>? history,
    int? hintsUsed,
  }) {
    return GameState(
      board: board ?? this.board,
      selectedRow: selectedRow,
      selectedCol: selectedCol,
      difficulty: difficulty ?? this.difficulty,
      elapsedTime: elapsedTime ?? this.elapsedTime,
      mistakes: mistakes ?? this.mistakes,
      isComplete: isComplete ?? this.isComplete,
      isPaused: isPaused ?? this.isPaused,
      showErrors: showErrors ?? this.showErrors,
      highlightNumbers: highlightNumbers ?? this.highlightNumbers,
      highlightRowCol: highlightRowCol ?? this.highlightRowCol,
      history: history ?? this.history,
      hintsUsed: hintsUsed ?? this.hintsUsed,
    );
  }
}

class GameAction {
  final int row;
  final int col;
  final int previousValue;
  final int newValue;
  final DateTime timestamp;

  GameAction({
    required this.row,
    required this.col,
    required this.previousValue,
    required this.newValue,
    required this.timestamp,
  });
}

// Game Notifier
class GameNotifier extends StateNotifier<GameState> {
  Timer? _timer;
  final SudokuGenerator _generator = SudokuGenerator();
  final SudokuSolver _solver = SudokuSolver();
  final SharedPreferences _prefs;

  GameNotifier(this._prefs) : super(const GameState()) {
    _loadLastGame();
  }

  Future<void> _loadLastGame() async {
    final savedBoard = _prefs.getString('last_game_board');
    final savedDifficulty = _prefs.getString('last_game_difficulty');
    final savedTime = _prefs.getInt('last_game_time');
    final savedMistakes = _prefs.getInt('last_game_mistakes');

    if (savedBoard != null && savedDifficulty != null) {
      // Parse saved board and resume game
      // This would require parsing the string back to a 2D list
    }
  }

  void startNewGame(String difficulty) {
    _timer?.cancel();

    Difficulty diff;
    switch (difficulty) {
      case 'Medium':
        diff = Difficulty.medium;
        break;
      case 'Hard':
        diff = Difficulty.hard;
        break;
      case 'Expert':
        diff = Difficulty.expert;
        break;
      case 'Evil':
        diff = Difficulty.evil;
        break;
      default:
        diff = Difficulty.easy;
    }

    final board = _generator.generatePuzzle(diff);

    state = GameState(
      board: board,
      difficulty: difficulty,
      elapsedTime: 0,
      mistakes: 0,
      isComplete: false,
      isPaused: false,
    );

    _startTimer();
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!state.isPaused && !state.isComplete) {
        state = state.copyWith(elapsedTime: state.elapsedTime + 1);
      }
    });
  }

  void selectCell(int row, int col) {
    if (state.isComplete || state.isPaused) return;
    state = state.copyWith(selectedRow: row, selectedCol: col);
  }

  void inputNumber(int number) {
    if (state.selectedRow == null || state.selectedCol == null) return;
    if (state.isComplete || state.isPaused) return;

    final cell = state.board!.getCell(state.selectedRow!, state.selectedCol!);
    if (cell.isFixed) return;

    final action = GameAction(
      row: state.selectedRow!,
      col: state.selectedCol!,
      previousValue: cell.value,
      newValue: number,
      timestamp: DateTime.now(),
    );

    final newHistory = [...state.history, action];

    // Check if placement is valid
    if (!state.board!.isValidPlacement(state.selectedRow!, state.selectedCol!, number)) {
      state.board!.setValue(state.selectedRow!, state.selectedCol!, number);
      final newMistakes = state.mistakes + 1;

      if (newMistakes >= AppConstants.maxMistakes) {
        state = state.copyWith(
          board: state.board,
          mistakes: newMistakes,
          history: newHistory,
          isComplete: true,
        );
        _timer?.cancel();
      } else {
        state = state.copyWith(
          board: state.board,
          mistakes: newMistakes,
          history: newHistory,
        );
      }
    } else {
      state.board!.setValue(state.selectedRow!, state.selectedCol!, number);
      state = state.copyWith(
        board: state.board,
        history: newHistory,
      );

      // Check if game is complete
      if (state.board!.isComplete()) {
        state = state.copyWith(isComplete: true);
        _timer?.cancel();
      }
    }
  }

  void togglePencilMark(int number) {
    if (state.selectedRow == null || state.selectedCol == null) return;
    if (state.isComplete || state.isPaused) return;

    final cell = state.board!.getCell(state.selectedRow!, state.selectedCol!);
    if (cell.isFixed || cell.value != 0) return;

    cell.togglePencilMark(number);
    state = state.copyWith(board: state.board);
  }

  void undo() {
    if (state.history.isEmpty) return;

    final lastAction = state.history.last;
    state.board!.setValue(lastAction.row, lastAction.col, lastAction.previousValue);

    final newHistory = [...state.history]..removeLast();
    state = state.copyWith(
      board: state.board,
      history: newHistory,
    );
  }

  void erase() {
    if (state.selectedRow == null || state.selectedCol == null) return;
    if (state.isComplete || state.isPaused) return;

    final cell = state.board!.getCell(state.selectedRow!, state.selectedCol!);
    if (cell.isFixed) return;

    inputNumber(0);
    state.board!.clearCell(state.selectedRow!, state.selectedCol!);
    state = state.copyWith(board: state.board);
  }

  void useHint() {
    if (state.selectedRow == null || state.selectedCol == null) return;

    final hint = _solver.findHint(state.board!);
    if (hint != null) {
      final row = hint ~/ 10;
      final col = (hint % 100) ~/ 10;
      final value = hint % 10;

      state.board!.setValue(row, col, value);

      final action = GameAction(
        row: row,
        col: col,
        previousValue: 0,
        newValue: value,
        timestamp: DateTime.now(),
      );

      final newHistory = [...state.history, action];
      state = state.copyWith(
        board: state.board,
        history: newHistory,
        hintsUsed: state.hintsUsed + 1,
      );

      if (state.board!.isComplete()) {
        state = state.copyWith(isComplete: true);
        _timer?.cancel();
      }
    }
  }

  void togglePause() {
    state = state.copyWith(isPaused: !state.isPaused);
  }

  void toggleShowErrors() {
    state = state.copyWith(showErrors: !state.showErrors);
  }

  void toggleHighlightNumbers() {
    state = state.copyWith(highlightNumbers: !state.highlightNumbers);
  }

  void toggleHighlightRowCol() {
    state = state.copyWith(highlightRowCol: !state.highlightRowCol);
  }

  void saveGame() {
    // Save current game state to SharedPreferences
  }

  int calculateXpEarned() {
    int baseXp = AppConstants.difficultyXpRewards[state.difficulty] ?? 50;
    int bonusXp = state.isComplete && state.mistakes == 0
        ? AppConstants.perfectGameBonus
        : 0;
    int timeBonus = state.elapsedTime < 300 ? 20 : 0;
    return baseXp + bonusXp + timeBonus;
  }

  int calculateCoinsEarned() {
    int baseCoins = state.difficulty == 'Evil' ? 20 : state.difficulty == 'Expert' ? 15 : 10;
    return baseCoins;
  }

  bool isPerfectGame() {
    return state.isComplete && state.mistakes == 0 && state.hintsUsed == 0;
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}

// Provider
final gameProvider = StateNotifierProvider<GameNotifier, GameState>((ref) {
  return GameNotifier(ref.watch(sharedPreferencesProvider));
});

// SharedPreferences Provider
final sharedPreferencesProvider = Provider<SharedPreferences>((ref) {
  throw UnimplementedError('Initialize in main.dart');
});