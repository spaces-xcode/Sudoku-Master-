// Settings Provider for Sudoku Master
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'auth_provider.dart';

// App Settings Model
class AppSettings {
  final bool soundEnabled;
  final bool vibrationEnabled;
  final String language;
  final bool notificationsEnabled;
  final bool autoCheckEnabled;
  final bool highlightSameNumbers;
  final bool highlightRowCol;
  final bool showMistakes;
  final String themeMode;

  const AppSettings({
    this.soundEnabled = true,
    this.vibrationEnabled = true,
    this.language = 'en',
    this.notificationsEnabled = true,
    this.autoCheckEnabled = false,
    this.highlightSameNumbers = true,
    this.highlightRowCol = true,
    this.showMistakes = true,
    this.themeMode = 'light',
  });

  AppSettings copyWith({
    bool? soundEnabled,
    bool? vibrationEnabled,
    String? language,
    bool? notificationsEnabled,
    bool? autoCheckEnabled,
    bool? highlightSameNumbers,
    bool? highlightRowCol,
    bool? showMistakes,
    String? themeMode,
  }) {
    return AppSettings(
      soundEnabled: soundEnabled ?? this.soundEnabled,
      vibrationEnabled: vibrationEnabled ?? this.vibrationEnabled,
      language: language ?? this.language,
      notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
      autoCheckEnabled: autoCheckEnabled ?? this.autoCheckEnabled,
      highlightSameNumbers: highlightSameNumbers ?? this.highlightSameNumbers,
      highlightRowCol: highlightRowCol ?? this.highlightRowCol,
      showMistakes: showMistakes ?? this.showMistakes,
      themeMode: themeMode ?? this.themeMode,
    );
  }
}

// Settings Notifier
class SettingsNotifier extends StateNotifier<AppSettings> {
  final SharedPreferences _prefs;

  SettingsNotifier(this._prefs) : super(const AppSettings()) {
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    state = AppSettings(
      soundEnabled: _prefs.getBool('sound_enabled') ?? true,
      vibrationEnabled: _prefs.getBool('vibration_enabled') ?? true,
      language: _prefs.getString('language') ?? 'en',
      notificationsEnabled: _prefs.getBool('notifications_enabled') ?? true,
      autoCheckEnabled: _prefs.getBool('auto_check_enabled') ?? false,
      highlightSameNumbers: _prefs.getBool('highlight_same_numbers') ?? true,
      highlightRowCol: _prefs.getBool('highlight_row_col') ?? true,
      showMistakes: _prefs.getBool('show_mistakes') ?? true,
      themeMode: _prefs.getString('theme_mode') ?? 'light',
    );
  }

  Future<void> toggleSound() async {
    await _prefs.setBool('sound_enabled', !state.soundEnabled);
    state = state.copyWith(soundEnabled: !state.soundEnabled);
  }

  Future<void> toggleVibration() async {
    await _prefs.setBool('vibration_enabled', !state.vibrationEnabled);
    state = state.copyWith(vibrationEnabled: !state.vibrationEnabled);
  }

  Future<void> setLanguage(String language) async {
    await _prefs.setString('language', language);
    state = state.copyWith(language: language);
  }

  Future<void> toggleNotifications() async {
    await _prefs.setBool('notifications_enabled', !state.notificationsEnabled);
    state = state.copyWith(notificationsEnabled: !state.notificationsEnabled);
  }

  Future<void> toggleAutoCheck() async {
    await _prefs.setBool('auto_check_enabled', !state.autoCheckEnabled);
    state = state.copyWith(autoCheckEnabled: !state.autoCheckEnabled);
  }

  Future<void> toggleHighlightSameNumbers() async {
    await _prefs.setBool('highlight_same_numbers', !state.highlightSameNumbers);
    state = state.copyWith(highlightSameNumbers: !state.highlightSameNumbers);
  }

  Future<void> toggleHighlightRowCol() async {
    await _prefs.setBool('highlight_row_col', !state.highlightRowCol);
    state = state.copyWith(highlightRowCol: !state.highlightRowCol);
  }

  Future<void> toggleShowMistakes() async {
    await _prefs.setBool('show_mistakes', !state.showMistakes);
    state = state.copyWith(showMistakes: !state.showMistakes);
  }

  Future<void> setThemeMode(String mode) async {
    await _prefs.setString('theme_mode', mode);
    state = state.copyWith(themeMode: mode);
  }
}

// Provider
final settingsProvider = StateNotifierProvider<SettingsNotifier, AppSettings>((ref) {
  return SettingsNotifier(ref.watch(sharedPreferencesProvider));
});