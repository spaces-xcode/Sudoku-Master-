// Authentication Provider for Sudoku Master
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../data/services/supabase_service.dart';
import '../../data/models/user_model.dart';
import '../../data/repositories/user_repository.dart';

// Auth state
enum AuthStatus { initial, loading, authenticated, unauthenticated, error }

class AuthState {
  final AuthStatus status;
  final UserModel? user;
  final String? errorMessage;

  const AuthState({
    this.status = AuthStatus.initial,
    this.user,
    this.errorMessage,
  });

  AuthState copyWith({
    AuthStatus? status,
    UserModel? user,
    String? errorMessage,
  }) {
    return AuthState(
      status: status ?? this.status,
      user: user ?? this.user,
      errorMessage: errorMessage,
    );
  }
}

// Auth Notifier
class AuthNotifier extends StateNotifier<AuthState> {
  final SupabaseService _supabase = SupabaseService();
  final UserRepository _userRepository = UserRepository();

  AuthNotifier() : super(const AuthState()) {
    _checkInitialAuth();
  }

  Future<void> _checkInitialAuth() async {
    final user = _supabase.currentUser;
    if (user != null) {
      state = state.copyWith(status: AuthStatus.loading);
      try {
        final userModel = await _userRepository.getUser(user.id);
        if (userModel != null) {
          state = AuthState(
            status: AuthStatus.authenticated,
            user: userModel,
          );
        } else {
          // Create new user if not found
          final newUser = UserModel(
            id: user.id,
            email: user.email ?? '',
            username: user.userMetadata?['name'] as String? ?? 'Player',
            avatarUrl: user.userMetadata?['avatar_url'] as String?,
            createdAt: DateTime.now(),
            updatedAt: DateTime.now(),
          );
          await _userRepository.createUser(newUser);
          state = AuthState(
            status: AuthStatus.authenticated,
            user: newUser,
          );
        }
      } catch (e) {
        state = const AuthState(status: AuthStatus.error);
      }
    } else {
      state = const AuthState(status: AuthStatus.unauthenticated);
    }
  }

  Future<void> signInWithEmail(String email, String password) async {
    state = state.copyWith(status: AuthStatus.loading);
    try {
      final response = await _supabase.signIn(email, password);
      if (response.user != null) {
        final userModel = await _userRepository.getUser(response.user!.id);
        state = AuthState(
          status: AuthStatus.authenticated,
          user: userModel,
        );
      }
    } on AuthException catch (e) {
      state = AuthState(
        status: AuthStatus.error,
        errorMessage: e.message,
      );
    }
  }

  Future<void> signUpWithEmail(String email, String password, String username) async {
    state = state.copyWith(status: AuthStatus.loading);
    try {
      final response = await _supabase.signUp(email, password);
      if (response.user != null) {
        final newUser = UserModel(
          id: response.user!.id,
          email: email,
          username: username,
          createdAt: DateTime.now(),
          updatedAt: DateTime.now(),
        );
        await _userRepository.createUser(newUser);
        state = AuthState(
          status: AuthStatus.authenticated,
          user: newUser,
        );
      }
    } on AuthException catch (e) {
      state = AuthState(
        status: AuthStatus.error,
        errorMessage: e.message,
      );
    }
  }

  Future<void> signInWithGoogle() async {
    state = state.copyWith(status: AuthStatus.loading);
    try {
      // Note: This requires additional Google Sign In setup
      // For now, we'll use a simplified version
      state = const AuthState(status: AuthStatus.unauthenticated);
    } catch (e) {
      state = AuthState(
        status: AuthStatus.error,
        errorMessage: e.toString(),
      );
    }
  }

  Future<void> signInAsGuest() async {
    state = state.copyWith(status: AuthStatus.loading);
    try {
      // Create a guest user
      final guestId = 'guest_${DateTime.now().millisecondsSinceEpoch}';
      final guestUser = UserModel(
        id: guestId,
        email: '$guestId@sudokumaster.guest',
        username: 'Guest',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
      await _userRepository.createUser(guestUser);
      state = AuthState(
        status: AuthStatus.authenticated,
        user: guestUser,
      );
    } catch (e) {
      state = AuthState(
        status: AuthStatus.error,
        errorMessage: e.toString(),
      );
    }
  }

  Future<void> signOut() async {
    await _supabase.signOut();
    state = const AuthState(status: AuthStatus.unauthenticated);
  }

  void updateUser(UserModel user) {
    state = state.copyWith(user: user);
  }
}

// Provider
final authProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  return AuthNotifier();
});