// Settings Screen for Sudoku Master
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_theme.dart';
import '../providers/settings_provider.dart';
import '../providers/auth_provider.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsProvider);
    final authState = ref.watch(authProvider);

    return Scaffold(
      backgroundColor: AppTheme.backgroundLight,
      appBar: AppBar(
        title: const Text('Settings'),
        backgroundColor: AppTheme.backgroundLight,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          // User section
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: AppTheme.surfaceLight,
              borderRadius: BorderRadius.circular(20),
              boxShadow: AppTheme.softShadow,
            ),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 32,
                  backgroundColor: AppTheme.primaryBlue.withOpacity(0.1),
                  child: Text(
                    (authState.user?.username ?? 'P')[0].toUpperCase(),
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: AppTheme.primaryBlue,
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        authState.user?.username ?? 'Guest',
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        authState.user?.email ?? 'guest@sudokumaster.app',
                        style: const TextStyle(
                          fontSize: 14,
                          color: AppTheme.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.edit_outlined, color: AppTheme.textSecondary),
                ),
              ],
            ),
          ),

          const SizedBox(height: 32),

          // Game Settings Section
          _SectionTitle(title: 'Game Settings'),
          const SizedBox(height: 16),

          _SettingsTile(
            icon: Icons.volume_up_outlined,
            title: 'Sound Effects',
            trailing: Switch(
              value: settings.soundEnabled,
              onChanged: (value) => ref.read(settingsProvider.notifier).toggleSound(),
              activeColor: AppTheme.primaryBlue,
            ),
          ),
          _SettingsTile(
            icon: Icons.vibration,
            title: 'Vibration',
            trailing: Switch(
              value: settings.vibrationEnabled,
              onChanged: (value) => ref.read(settingsProvider.notifier).toggleVibration(),
              activeColor: AppTheme.primaryBlue,
            ),
          ),
          _SettingsTile(
            icon: Icons.highlight,
            title: 'Highlight Same Numbers',
            trailing: Switch(
              value: settings.highlightSameNumbers,
              onChanged: (value) => ref.read(settingsProvider.notifier).toggleHighlightSameNumbers(),
              activeColor: AppTheme.primaryBlue,
            ),
          ),
          _SettingsTile(
            icon: Icons.grid_on,
            title: 'Highlight Row & Column',
            trailing: Switch(
              value: settings.highlightRowCol,
              onChanged: (value) => ref.read(settingsProvider.notifier).toggleHighlightRowCol(),
              activeColor: AppTheme.primaryBlue,
            ),
          ),
          _SettingsTile(
            icon: Icons.error_outline,
            title: 'Show Mistakes',
            trailing: Switch(
              value: settings.showMistakes,
              onChanged: (value) => ref.read(settingsProvider.notifier).toggleShowMistakes(),
              activeColor: AppTheme.primaryBlue,
            ),
          ),

          const SizedBox(height: 32),

          // Appearance Section
          _SectionTitle(title: 'Appearance'),
          const SizedBox(height: 16),

          _SettingsTile(
            icon: Icons.palette_outlined,
            title: 'App Theme',
            subtitle: _getThemeName(settings.themeMode),
            onTap: () => _showThemeSelector(context, ref),
          ),

          const SizedBox(height: 32),

          // General Section
          _SectionTitle(title: 'General'),
          const SizedBox(height: 16),

          _SettingsTile(
            icon: Icons.language,
            title: 'Language',
            subtitle: _getLanguageName(settings.language),
            onTap: () => _showLanguageSelector(context, ref),
          ),
          _SettingsTile(
            icon: Icons.notifications_outlined,
            title: 'Notifications',
            trailing: Switch(
              value: settings.notificationsEnabled,
              onChanged: (value) => ref.read(settingsProvider.notifier).toggleNotifications(),
              activeColor: AppTheme.primaryBlue,
            ),
          ),
          _SettingsTile(
            icon: Icons.cloud_outlined,
            title: 'Cloud Sync',
            subtitle: 'Last synced: Today',
            onTap: () {},
          ),

          const SizedBox(height: 32),

          // About Section
          _SectionTitle(title: 'About'),
          const SizedBox(height: 16),

          _SettingsTile(
            icon: Icons.info_outline,
            title: 'About Sudoku Master',
            subtitle: 'Version 1.0.0',
            onTap: () => _showAboutDialog(context),
          ),
          _SettingsTile(
            icon: Icons.privacy_tip_outlined,
            title: 'Privacy Policy',
            onTap: () {},
          ),
          _SettingsTile(
            icon: Icons.description_outlined,
            title: 'Terms of Service',
            onTap: () {},
          ),

          const SizedBox(height: 32),

          // Sign Out Button
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () {
                ref.read(authProvider.notifier).signOut();
              },
              icon: const Icon(Icons.logout, color: AppTheme.error),
              label: const Text(
                'Sign Out',
                style: TextStyle(color: AppTheme.error),
              ),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: AppTheme.error),
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),

          const SizedBox(height: 32),
        ],
      ),
    );
  }

  String _getThemeName(String mode) {
    switch (mode) {
      case 'dark':
        return 'Dark Mode';
      case 'light':
        return 'Light Mode';
      case 'system':
        return 'System Default';
      case 'ocean':
        return 'Ocean Blue';
      case 'neon':
        return 'Neon';
      case 'gold':
        return 'Gold Master';
      default:
        return 'Light Mode';
    }
  }

  String _getLanguageName(String code) {
    switch (code) {
      case 'en':
        return 'English';
      case 'zh':
        return '中文';
      case 'es':
        return 'Español';
      case 'fr':
        return 'Français';
      case 'de':
        return 'Deutsch';
      default:
        return 'English';
    }
  }

  void _showThemeSelector(BuildContext context, WidgetRef ref) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: const EdgeInsets.all(24),
        decoration: const BoxDecoration(
          color: AppTheme.surfaceLight,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Select Theme',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            ...['light', 'dark', 'ocean', 'neon', 'gold'].map((theme) {
              final names = {
                'light': 'Light Mode',
                'dark': 'Dark Mode',
                'ocean': 'Ocean Blue',
                'neon': 'Neon',
                'gold': 'Gold Master',
              };
              final colors = {
                'light': Colors.white,
                'dark': Colors.grey[800],
                'ocean': const Color(0xFF0EA5E9),
                'neon': const Color(0xFF00FFFF),
                'gold': const Color(0xFFFFD700),
              };
              return ListTile(
                leading: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: colors[theme],
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.grey.withOpacity(0.3)),
                  ),
                ),
                title: Text(names[theme]!),
                onTap: () {
                  ref.read(settingsProvider.notifier).setThemeMode(theme);
                  Navigator.pop(context);
                },
              );
            }),
          ],
        ),
      ),
    );
  }

  void _showLanguageSelector(BuildContext context, WidgetRef ref) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: const EdgeInsets.all(24),
        decoration: const BoxDecoration(
          color: AppTheme.surfaceLight,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Select Language',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            ...['en', 'zh', 'es', 'fr', 'de'].map((lang) {
              final names = {
                'en': 'English',
                'zh': '中文',
                'es': 'Español',
                'fr': 'Français',
                'de': 'Deutsch',
              };
              return ListTile(
                title: Text(names[lang]!),
                onTap: () {
                  ref.read(settingsProvider.notifier).setLanguage(lang);
                  Navigator.pop(context);
                },
              );
            }),
          ],
        ),
      ),
    );
  }

  void _showAboutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: AppTheme.primaryGradient,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.grid_3x3, color: Colors.white),
            ),
            const SizedBox(width: 12),
            const Text('Sudoku Master'),
          ],
        ),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Version 1.0.0'),
            SizedBox(height: 12),
            Text(
              'A premium Sudoku experience with beautiful UI, challenging puzzles, and addictive progression.',
              style: TextStyle(color: AppTheme.textSecondary),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;

  const _SectionTitle({required this.title});

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w600,
        color: AppTheme.textSecondary,
        letterSpacing: 0.5,
      ),
    );
  }
}

class _SettingsTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;

  const _SettingsTile({
    required this.icon,
    required this.title,
    this.subtitle,
    this.trailing,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: AppTheme.surfaceLight,
        borderRadius: BorderRadius.circular(16),
        boxShadow: AppTheme.softShadow,
      ),
      child: ListTile(
        onTap: onTap,
        leading: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: AppTheme.primaryBlue.withOpacity(0.1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: AppTheme.primaryBlue, size: 20),
        ),
        title: Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.w500,
            color: AppTheme.textPrimary,
          ),
        ),
        subtitle: subtitle != null
            ? Text(
                subtitle!,
                style: const TextStyle(
                  fontSize: 12,
                  color: AppTheme.textSecondary,
                ),
              )
            : null,
        trailing: trailing ??
            (onTap != null
                ? const Icon(Icons.chevron_right, color: AppTheme.textSecondary)
                : null),
      ),
    );
  }
}