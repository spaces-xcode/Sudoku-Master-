// Game Screen for Sudoku Master
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:confetti/confetti.dart';
import '../../core/theme/app_theme.dart';
import '../../core/constants/app_constants.dart';
import '../../core/utils/sudoku_logic.dart';
import '../providers/game_provider.dart';
import '../widgets/sudoku_grid.dart';

class GameScreen extends ConsumerStatefulWidget {
  final String difficulty;

  const GameScreen({super.key, required this.difficulty});

  @override
  ConsumerState<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends ConsumerState<GameScreen> {
  late ConfettiController _confettiController;
  bool _pencilMode = false;
  bool _showControls = true;

  @override
  void initState() {
    super.initState();
    _confettiController = ConfettiController(duration: const Duration(seconds: 3));

    // Start new game on init
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(gameProvider.notifier).startNewGame(widget.difficulty);
    });
  }

  @override
  void dispose() {
    _confettiController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final gameState = ref.watch(gameProvider);

    // Play confetti on win
    if (gameState.isComplete && !gameState.isPaused) {
      _confettiController.play();
    }

    return Scaffold(
      backgroundColor: AppTheme.backgroundLight,
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              children: [
                // Top bar
                _buildTopBar(gameState),

                // Game info
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TimerDisplay(seconds: gameState.elapsedTime),
                      MistakeCounter(mistakes: gameState.mistakes),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                // Sudoku Grid
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: SudokuGrid(
                    board: gameState.board!,
                    selectedRow: gameState.selectedRow,
                    selectedCol: gameState.selectedCol,
                    highlightNumbers: gameState.highlightNumbers,
                    highlightRowCol: gameState.highlightRowCol,
                    onCellTap: (index) {
                      final row = index ~/ 9;
                      final col = index % 9;
                      ref.read(gameProvider.notifier).selectCell(row, col);
                    },
                  ),
                ),

                const SizedBox(height: 16),

                // Number Pad
                if (_showControls)
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: NumberPad(
                      onNumberTap: (number) {
                        if (_pencilMode) {
                          ref.read(gameProvider.notifier).togglePencilMark(number);
                        } else {
                          ref.read(gameProvider.notifier).inputNumber(number);
                        }
                      },
                      onUndoTap: () => ref.read(gameProvider.notifier).undo(),
                      onEraseTap: () => ref.read(gameProvider.notifier).erase(),
                      onHintTap: () => ref.read(gameProvider.notifier).useHint(),
                      onPencilTap: () => setState(() => _pencilMode = !_pencilMode),
                      pencilMode: _pencilMode,
                    ),
                  ),

                const Spacer(),

                // Bottom action bar
                _buildBottomActionBar(gameState),
              ],
            ),

            // Confetti overlay
            Align(
              alignment: Alignment.topCenter,
              child: ConfettiWidget(
                confettiController: _confettiController,
                blastDirectionality: BlastDirectionality.explosive,
                shouldLoop: false,
                colors: const [
                  AppTheme.primaryBlue,
                  AppTheme.accentCyan,
                  AppTheme.warning,
                  AppTheme.success,
                ],
              ),
            ),

            // Pause overlay
            if (gameState.isPaused) _buildPauseOverlay(),

            // Game complete overlay
            if (gameState.isComplete && !gameState.isPaused)
              _buildCompleteOverlay(gameState),
          ],
        ),
      ),
    );
  }

  Widget _buildTopBar(GameState gameState) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppTheme.surfaceLight,
                borderRadius: BorderRadius.circular(12),
                boxShadow: AppTheme.softShadow,
              ),
              child: const Icon(Icons.arrow_back_ios_new, color: AppTheme.textPrimary),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              widget.difficulty,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
                color: AppTheme.textPrimary,
              ),
            ),
          ),
          GestureDetector(
            onTap: () => ref.read(gameProvider.notifier).togglePause(),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppTheme.surfaceLight,
                borderRadius: BorderRadius.circular(12),
                boxShadow: AppTheme.softShadow,
              ),
              child: Icon(
                gameState.isPaused ? Icons.play_arrow : Icons.pause,
                color: AppTheme.textPrimary,
              ),
            ),
          ),
          const SizedBox(width: 8),
          GestureDetector(
            onTap: () => _showSettingsSheet(),
            child: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: AppTheme.surfaceLight,
                borderRadius: BorderRadius.circular(12),
                boxShadow: AppTheme.softShadow,
              ),
              child: const Icon(Icons.settings_outlined, color: AppTheme.textPrimary),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomActionBar(GameState gameState) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppTheme.surfaceLight,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _ActionBarButton(
            icon: Icons.grid_view_rounded,
            label: 'Grid',
            onTap: () {},
          ),
          _ActionBarButton(
            icon: Icons.undo_rounded,
            label: 'Undo',
            onTap: () => ref.read(gameProvider.notifier).undo(),
          ),
          _ActionBarButton(
            icon: Icons.lightbulb_outline_rounded,
            label: 'Hint',
            onTap: () => ref.read(gameProvider.notifier).useHint(),
          ),
          _ActionBarButton(
            icon: gameState.highlightNumbers ? Icons.highlight : Icons.highlight_outlined,
            label: 'Highlight',
            onTap: () => ref.read(gameProvider.notifier).toggleHighlightNumbers(),
            isActive: gameState.highlightNumbers,
          ),
          _ActionBarButton(
            icon: Icons.visibility_outlined,
            label: 'Notes',
            onTap: () => setState(() => _pencilMode = !_pencilMode),
            isActive: _pencilMode,
          ),
        ],
      ),
    );
  }

  Widget _buildPauseOverlay() {
    return Container(
      color: Colors.black.withOpacity(0.5),
      child: Center(
        child: Container(
          margin: const EdgeInsets.all(32),
          padding: const EdgeInsets.all(32),
          decoration: BoxDecoration(
            color: AppTheme.surfaceLight,
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.pause_circle_outline,
                size: 64,
                color: AppTheme.primaryBlue,
              ),
              const SizedBox(height: 16),
              const Text(
                'Game Paused',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.textPrimary,
                ),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => ref.read(gameProvider.notifier).togglePause(),
                  child: const Text('Resume'),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () {
                    ref.read(gameProvider.notifier).saveGame();
                    Navigator.pop(context);
                  },
                  child: const Text('Save & Exit'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCompleteOverlay(GameState gameState) {
    final xpEarned = ref.read(gameProvider.notifier).calculateXpEarned();
    final coinsEarned = ref.read(gameProvider.notifier).calculateCoinsEarned();
    final isPerfect = ref.read(gameProvider.notifier).isPerfectGame();

    return Container(
      color: Colors.black.withOpacity(0.7),
      child: Center(
        child: Container(
          margin: const EdgeInsets.all(32),
          padding: const EdgeInsets.all(32),
          decoration: BoxDecoration(
            color: AppTheme.surfaceLight,
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                isPerfect ? Icons.emoji_events : Icons.celebration,
                size: 80,
                color: isPerfect ? AppTheme.warning : AppTheme.primaryBlue,
              ),
              const SizedBox(height: 16),
              Text(
                isPerfect ? 'Perfect!' : 'Congratulations!',
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.textPrimary,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                '${widget.difficulty} completed in ${_formatTime(gameState.elapsedTime)}',
                style: const TextStyle(
                  fontSize: 16,
                  color: AppTheme.textSecondary,
                ),
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _RewardBadge(
                    icon: Icons.star,
                    value: '+$xpEarned',
                    label: 'XP',
                    color: AppTheme.primaryBlue,
                  ),
                  const SizedBox(width: 24),
                  _RewardBadge(
                    icon: Icons.monetization_on,
                    value: '+$coinsEarned',
                    label: 'Coins',
                    color: AppTheme.warning,
                  ),
                ],
              ),
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Continue'),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  onPressed: () {
                    Navigator.pop(context);
                    ref.read(gameProvider.notifier).startNewGame(widget.difficulty);
                  },
                  child: const Text('Play Again'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showSettingsSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: const EdgeInsets.all(24),
        decoration: const BoxDecoration(
          color: AppTheme.surfaceLight,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Game Settings',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: AppTheme.textPrimary,
              ),
            ),
            const SizedBox(height: 20),
            SwitchListTile(
              title: const Text('Highlight same numbers'),
              value: ref.watch(gameProvider).highlightNumbers,
              onChanged: (value) {
                ref.read(gameProvider.notifier).toggleHighlightNumbers();
              },
            ),
            SwitchListTile(
              title: const Text('Highlight row & column'),
              value: ref.watch(gameProvider).highlightRowCol,
              onChanged: (value) {
                ref.read(gameProvider.notifier).toggleHighlightRowCol();
              },
            ),
            SwitchListTile(
              title: const Text('Show errors'),
              value: ref.watch(gameProvider).showErrors,
              onChanged: (value) {
                ref.read(gameProvider.notifier).toggleShowErrors();
              },
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: () {
                  Navigator.pop(context);
                  ref.read(gameProvider.notifier).startNewGame(widget.difficulty);
                },
                child: const Text('New Game'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatTime(int seconds) {
    final minutes = seconds ~/ 60;
    final secs = seconds % 60;
    return '${minutes}m ${secs}s';
  }
}

class _ActionBarButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool isActive;

  const _ActionBarButton({
    required this.icon,
    required this.label,
    required this.onTap,
    this.isActive = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: isActive ? AppTheme.primaryBlue.withOpacity(0.1) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: isActive ? AppTheme.primaryBlue : AppTheme.textSecondary,
              size: 24,
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                color: isActive ? AppTheme.primaryBlue : AppTheme.textSecondary,
                fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RewardBadge extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  final Color color;

  const _RewardBadge({
    required this.icon,
    required this.value,
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: color, size: 32),
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        Text(
          label,
          style: const TextStyle(
            fontSize: 12,
            color: AppTheme.textSecondary,
          ),
        ),
      ],
    );
  }
}