// Leaderboard Screen for Sudoku Master
import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../../data/models/ranking_model.dart';

class LeaderboardScreen extends StatefulWidget {
  const LeaderboardScreen({super.key});

  @override
  State<LeaderboardScreen> createState() => _LeaderboardScreenState();
}

class _LeaderboardScreenState extends State<LeaderboardScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundLight,
      appBar: AppBar(
        title: const Text('Leaderboard'),
        backgroundColor: AppTheme.backgroundLight,
        elevation: 0,
        bottom: TabBar(
          controller: _tabController,
          labelColor: AppTheme.primaryBlue,
          unselectedLabelColor: AppTheme.textSecondary,
          indicatorColor: AppTheme.primaryBlue,
          tabs: const [
            Tab(text: 'All Time'),
            Tab(text: 'Weekly'),
            Tab(text: 'Monthly'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildLeaderboardList(_mockRankings.take(50).toList()),
          _buildLeaderboardList(_mockRankings.take(30).toList()),
          _buildLeaderboardList(_mockRankings.take(20).toList()),
        ],
      ),
    );
  }

  Widget _buildLeaderboardList(List<RankingModel> rankings) {
    // Add mock data
    final mockRankings = [
      RankingModel(odId: '1', username: 'SudokuPro', level: 45, totalXp: 4500, gamesPlayed: 500, gamesWon: 480, weeklyScore: 1200),
      RankingModel(odId: '2', username: 'MasterMind', level: 42, totalXp: 4200, gamesPlayed: 450, gamesWon: 420, weeklyScore: 1150),
      RankingModel(odId: '3', username: 'NumberKing', level: 40, totalXp: 4000, gamesPlayed: 400, gamesWon: 380, weeklyScore: 1100),
      RankingModel(odId: '4', username: 'PuzzleQueen', level: 38, totalXp: 3800, gamesPlayed: 380, gamesWon: 360, weeklyScore: 1050),
      RankingModel(odId: '5', username: 'GridGuru', level: 36, totalXp: 3600, gamesPlayed: 360, gamesWon: 340, weeklyScore: 1000),
    ];

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: mockRankings.length + 1,
      itemBuilder: (context, index) {
        if (index == 0) {
          return _buildTopThree(mockRankings.take(3).toList());
        }

        final rank = mockRankings[index - 1];
        return _buildLeaderboardItem(rank, index + 1);
      },
    );
  }

  Widget _buildTopThree(List<RankingModel> topThree) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 24),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // 2nd place
          if (topThree.length > 1)
            _buildTopItem(topThree[1], 2, Colors.grey[400]!),

          const SizedBox(width: 8),

          // 1st place
          _buildTopItem(topThree[0], 1, const Color(0xFFFFD700)),

          const SizedBox(width: 8),

          // 3rd place
          if (topThree.length > 2)
            _buildTopItem(topThree[2], 3, const Color(0xFFCD7F32)),
        ],
      ),
    );
  }

  Widget _buildTopItem(RankingModel ranking, int place, Color color) {
    final height = place == 1 ? 140.0 : 110.0;

    return Column(
      children: [
        // Avatar
        Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: color.withOpacity(0.2),
            border: Border.all(color: color, width: 3),
          ),
          child: Center(
            child: Text(
              ranking.username[0].toUpperCase(),
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          ranking.username,
          style: const TextStyle(
            fontWeight: FontWeight.w600,
            color: AppTheme.textPrimary,
          ),
        ),
        Text(
          'Level ${ranking.level}',
          style: const TextStyle(
            fontSize: 12,
            color: AppTheme.textSecondary,
          ),
        ),
        const SizedBox(height: 8),
        // Trophy or medal
        Container(
          width: height * 0.4,
          height: height * 0.5,
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Center(
            child: place == 1
                ? const Icon(Icons.emoji_events, color: Color(0xFFFFD700), size: 32)
                : Text(
                    '#$place',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: color,
                    ),
                  ),
          ),
        ),
      ],
    );
  }

  Widget _buildLeaderboardItem(RankingModel ranking, int rank) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.surfaceLight,
        borderRadius: BorderRadius.circular(16),
        boxShadow: AppTheme.softShadow,
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: rank <= 10 ? AppTheme.primaryBlue.withOpacity(0.1) : Colors.transparent,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Center(
              child: Text(
                '#$rank',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  color: rank <= 10 ? AppTheme.primaryBlue : AppTheme.textSecondary,
                ),
              ),
            ),
          ),
          const SizedBox(width: 16),
          CircleAvatar(
            radius: 20,
            backgroundColor: AppTheme.primaryBlue.withOpacity(0.1),
            child: Text(
              ranking.username[0].toUpperCase(),
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                color: AppTheme.primaryBlue,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  ranking.username,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    color: AppTheme.textPrimary,
                  ),
                ),
                Text(
                  'Level ${ranking.level} • ${ranking.gamesWon} wins',
                  style: const TextStyle(
                    fontSize: 12,
                    color: AppTheme.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '${ranking.totalXp}',
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  color: AppTheme.primaryBlue,
                ),
              ),
              const Text(
                'XP',
                style: TextStyle(
                  fontSize: 10,
                  color: AppTheme.textSecondary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// Mock data
final _mockRankings = List.generate(
  100,
  (index) => RankingModel(
    odId: '${index + 1}',
    username: 'Player${index + 1}',
    level: 100 - index,
    totalXp: (100 - index) * 100,
    gamesPlayed: 100 + index * 5,
    gamesWon: 90 + index * 4,
    weeklyScore: 500 + index * 10,
  ),
);