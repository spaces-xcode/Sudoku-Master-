// Themes Screen for Sudoku Master
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_theme.dart';
import '../providers/settings_provider.dart';

class ThemesScreen extends ConsumerWidget {
  const ThemesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final currentTheme = ref.watch(settingsProvider).themeMode;

    final themes = [
      {'id': 'light', 'name': 'Minimal White', 'icon': Icons.wb_sunny_outlined},
      {'id': 'dark', 'name': 'Dark Mode', 'icon': Icons.dark_mode_outlined},
      {'id': 'ocean', 'name': 'Ocean Blue', 'icon': Icons.water_outlined},
      {'id': 'neon', 'name': 'Neon', 'icon': Icons.flare_outlined},
      {'id': 'gold', 'name': 'Gold Master', 'icon': Icons.stars_outlined},
    ];

    return Scaffold(
      backgroundColor: AppTheme.backgroundLight,
      appBar: AppBar(
        title: const Text('Themes'),
        backgroundColor: AppTheme.backgroundLight,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Choose Your Style',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: AppTheme.textPrimary,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Personalize your Sudoku Master experience',
              style: TextStyle(
                color: AppTheme.textSecondary,
              ),
            ),
            const SizedBox(height: 24),
            Expanded(
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  childAspectRatio: 1.1,
                ),
                itemCount: themes.length,
                itemBuilder: (context, index) {
                  final theme = themes[index];
                  final isSelected = currentTheme == theme['id'];

                  return _ThemeCard(
                    id: theme['id'] as String,
                    name: theme['name'] as String,
                    icon: theme['icon'] as IconData,
                    isSelected: isSelected,
                    onTap: () {
                      ref.read(settingsProvider.notifier).setThemeMode(theme['id'] as String);
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ThemeCard extends StatelessWidget {
  final String id;
  final String name;
  final IconData icon;
  final bool isSelected;
  final VoidCallback onTap;

  const _ThemeCard({
    required this.id,
    required this.name,
    required this.icon,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final colors = {
      'light': Colors.white,
      'dark': Colors.grey[800]!,
      'ocean': const Color(0xFF0EA5E9),
      'neon': const Color(0xFF00FFFF),
      'gold': const Color(0xFFFFD700),
    };

    final backgroundColors = {
      'light': const Color(0xFFF8FAFC),
      'dark': const Color(0xFF1E293B),
      'ocean': const Color(0xFFF0F9FF),
      'neon': const Color(0xFF0A0A0A),
      'gold': const Color(0xFFFFFBEB),
    };

    final textColors = {
      'light': AppTheme.textPrimary,
      'dark': Colors.white,
      'ocean': const Color(0xFF0EA5E9),
      'neon': const Color(0xFF00FFFF),
      'gold': const Color(0xFFFFD700),
    };

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        decoration: BoxDecoration(
          color: backgroundColors[id],
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected ? colors[id]! : Colors.transparent,
            width: 3,
          ),
          boxShadow: isSelected ? [
            BoxShadow(
              color: colors[id]!.withOpacity(0.3),
              blurRadius: 15,
              offset: const Offset(0, 5),
            ),
          ] : AppTheme.softShadow,
        ),
        child: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: colors[id]!.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      icon,
                      color: textColors[id],
                      size: 28,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    name,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: textColors[id],
                    ),
                  ),
                  const SizedBox(height: 4),
                  if (id == 'neon' || id == 'gold')
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: textColors[id]!.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        'Premium',
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          color: textColors[id],
                        ),
                      ),
                    ),
                ],
              ),
            ),
            if (isSelected)
              Positioned(
                top: 12,
                right: 12,
                child: Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: colors[id],
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.check,
                    color: Colors.white,
                    size: 16,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}