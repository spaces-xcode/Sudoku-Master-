// Home Screen for Sudoku Master
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'dart:math' as math;
import '../../core/theme/app_theme.dart';
import '../../core/widgets/circular_progress_indicator.dart';
import '../../core/widgets/buttons_and_cards.dart';
import '../providers/auth_provider.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authProvider);

    return Scaffold(
      backgroundColor: AppTheme.backgroundLight,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              // Header
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Sudoku Master',
                        style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: AppTheme.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        authState.user?.username ?? 'Player',
                        style: const TextStyle(
                          color: AppTheme.textSecondary,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppTheme.surfaceLight,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: AppTheme.softShadow,
                    ),
                    child: const Icon(
                      Icons.notifications_outlined,
                      color: AppTheme.textPrimary,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 40),

              // Circular Progress with floating buttons
              Stack(
                alignment: Alignment.center,
                children: [
                  // Floating buttons
                  ..._buildFloatingButtons(),

                  // Animated glow effect
                  AnimatedBuilder(
                    animation: _animationController,
                    builder: (context, child) {
                      return Container(
                        width: 220 + math.sin(_animationController.value * 2 * math.pi) * 10,
                        height: 220 + math.sin(_animationController.value * 2 * math.pi) * 10,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: AppTheme.primaryBlue.withOpacity(0.1),
                              blurRadius: 40,
                              spreadRadius: 10,
                            ),
                          ],
                        ),
                      );
                    },
                  ),

                  // Main progress indicator
                  CircularLevelIndicator(
                    level: authState.user?.level ?? 1,
                    xp: authState.user?.xp ?? 0,
                    xpForNextLevel: 100,
                    tierName: authState.user?.tierName ?? 'Beginner',
                    size: 200,
                  ),
                ],
              ),

              const SizedBox(height: 40),

              // New Game Button
              PrimaryButton(
                text: 'New Game',
                icon: Icons.play_arrow_rounded,
                width: double.infinity,
                onPressed: () => _showDifficultySelector(context),
              ),

              const SizedBox(height: 24),

              // Quick Stats Row
              Row(
                children: [
                  Expanded(
                    child: _QuickStatCard(
                      icon: Icons.emoji_events_outlined,
                      value: '${authState.user?.gamesWon ?? 0}',
                      label: 'Wins',
                      color: AppTheme.warning,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _QuickStatCard(
                      icon: Icons.local_fire_department_outlined,
                      value: '${authState.user?.currentStreak ?? 0}',
                      label: 'Streak',
                      color: AppTheme.error,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _QuickStatCard(
                      icon: Icons.monetization_on_outlined,
                      value: '${authState.user?.coins ?? 0}',
                      label: 'Coins',
                      color: AppTheme.accentCyan,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 32),

              // Continue Last Game (if available)
              _buildContinueLastGame(),

              const SizedBox(height: 24),

              // Daily Challenge Card
              _buildDailyChallengeCard(),

              const SizedBox(height: 24),

              // Recent Activity
              _buildRecentActivity(),
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _buildFloatingButtons() {
    final buttons = [
      {'icon': Icons.leaderboard_outlined, 'label': 'Ranking', 'angle': -math.pi / 2 - 0.4},
      {'icon': Icons.star_outline_rounded, 'label': 'Perfect', 'angle': -math.pi / 2 + 0.4},
      {'icon': Icons.emoji_events_outlined, 'label': 'Achievements', 'angle': math.pi / 2 - 0.4},
      {'icon': Icons.calendar_today_outlined, 'label': 'Calendar', 'angle': math.pi / 2 + 0.4},
    ];

    return buttons.asMap().entries.map((entry) {
      final index = entry.key;
      final button = entry.value;
      final angle = button['angle'] as double;
      const radius = 120.0;

      final x = math.cos(angle) * radius;
      final y = math.sin(angle) * radius;

      return Transform.translate(
        offset: Offset(x, y),
        child: FloatingActionCard(
          icon: button['icon'] as IconData,
          label: button['label'] as String,
          size: 60,
          onTap: () => _onFeatureTap(index),
        ),
      );
    }).toList();
  }

  void _onFeatureTap(int index) {
    switch (index) {
      case 0:
        Navigator.pushNamed(context, '/leaderboard');
        break;
      case 1:
        Navigator.pushNamed(context, '/perfect-ranking');
        break;
      case 2:
        Navigator.pushNamed(context, '/achievements');
        break;
      case 3:
        Navigator.pushNamed(context, '/calendar');
        break;
    }
  }

  void _showDifficultySelector(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        padding: const EdgeInsets.all(24),
        decoration: const BoxDecoration(
          color: AppTheme.surfaceLight,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Select Difficulty',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: AppTheme.textPrimary,
              ),
            ),
            const SizedBox(height: 20),
            ...['Easy', 'Medium', 'Hard', 'Expert', 'Evil'].map((difficulty) {
              final colors = {
                'Easy': AppTheme.success,
                'Medium': AppTheme.primaryBlue,
                'Hard': AppTheme.warning,
                'Expert': AppTheme.accentPurple,
                'Evil': AppTheme.error,
              };
              final icons = {
                'Easy': Icons.sentiment_satisfied_alt,
                'Medium': Icons.sentiment_neutral,
                'Hard': Icons.sentiment_dissatisfied,
                'Expert': Icons.sentiment_very_dissatisfied,
                'Evil': Icons.whatshot,
              };

              return ListTile(
                leading: Icon(icons[difficulty], color: colors[difficulty]),
                title: Text(difficulty),
                trailing: const Icon(Icons.chevron_right),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.pushNamed(context, '/game', arguments: difficulty);
                },
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildContinueLastGame() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.primaryBlue.withOpacity(0.1),
            AppTheme.accentCyan.withOpacity(0.1),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: AppTheme.primaryBlue.withOpacity(0.2),
        ),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppTheme.primaryBlue.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.play_circle_outline,
              color: AppTheme.primaryBlue,
              size: 32,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Continue Last Game',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.textPrimary,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Medium - 15:32 - 1 mistake',
                  style: TextStyle(
                    fontSize: 14,
                    color: AppTheme.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          const Icon(
            Icons.chevron_right,
            color: AppTheme.textSecondary,
          ),
        ],
      ),
    );
  }

  Widget _buildDailyChallengeCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppTheme.primaryGradient,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: AppTheme.primaryBlue.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.calendar_today,
              color: Colors.white,
              size: 28,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Daily Challenge',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '+75 XP + 25 Coins',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.white.withOpacity(0.8),
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Text(
              'Play',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: AppTheme.primaryBlue,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecentActivity() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Recent Activity',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: AppTheme.textPrimary,
              ),
            ),
            TextButton(
              onPressed: () {},
              child: const Text('View All'),
            ),
          ],
        ),
        const SizedBox(height: 12),
        ...List.generate(3, (index) {
          final games = [
            {'difficulty': 'Hard', 'time': '12:45', 'xp': '+150', 'date': 'Today'},
            {'difficulty': 'Medium', 'time': '08:22', 'xp': '+100', 'date': 'Yesterday'},
            {'difficulty': 'Easy', 'time': '05:15', 'xp': '+50', 'date': '2 days ago'},
          ];
          final game = games[index];
          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.surfaceLight,
              borderRadius: BorderRadius.circular(16),
              boxShadow: AppTheme.softShadow,
            ),
            child: Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: AppTheme.success.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(
                    Icons.check_circle,
                    color: AppTheme.success,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${game['difficulty']} - ${game['time']}',
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          color: AppTheme.textPrimary,
                        ),
                      ),
                      Text(
                        game['date'] as String,
                        style: const TextStyle(
                          fontSize: 12,
                          color: AppTheme.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryBlue.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    game['xp'] as String,
                    style: const TextStyle(
                      color: AppTheme.primaryBlue,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          );
        }),
      ],
    );
  }
}

class _QuickStatCard extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  final Color color;

  const _QuickStatCard({
    required this.icon,
    required this.value,
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.surfaceLight,
        borderRadius: BorderRadius.circular(16),
        boxShadow: AppTheme.softShadow,
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: AppTheme.textPrimary,
            ),
          ),
          Text(
            label,
            style: const TextStyle(
              fontSize: 12,
              color: AppTheme.textSecondary,
            ),
          ),
        ],
      ),
    );
  }
}