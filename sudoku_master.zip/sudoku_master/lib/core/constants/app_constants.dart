// Core Constants for Sudoku Master App

class AppConstants {
  // App Info
  static const String appName = 'Sudoku Master';
  static const String appVersion = '1.0.0';

  // Supabase Configuration
  static const String supabaseUrl = 'https://gtpvvdlpjknqpbxpkclf.supabase.co';
  static const String supabaseAnonKey = 'sb_publishable_b-InbMJXFv18i7yjUxdiBQ_q1pm3P2g';

  // Game Settings
  static const int gridSize = 9;
  static const int boxSize = 3;
  static const int maxMistakes = 3;
  static const int hintCost = 10;

  // XP & Level System
  static const int xpPerLevel = 100;
  static const int maxLevel = 100;

  // Tier System
  static const List<String> tiers = [
    'Beginner',
    'Intermediate',
    'Expert',
    'Master',
    'Grandmaster'
  ];

  static const int tierThreshold = 20; // Level threshold for tier advancement

  // Difficulty Levels
  static const List<String> difficulties = [
    'Easy',
    'Medium',
    'Hard',
    'Expert',
    'Evil'
  ];

  // Time Limits (in seconds)
  static const Map<String, int> timeLimits = {
    'Easy': 1800,   // 30 min
    'Medium': 2400, // 40 min
    'Hard': 3000,   // 50 min
    'Expert': 3600, // 60 min
    'Evil': 4200,   // 70 min
  };

  // Rewards
  static const Map<String, int> difficultyXpRewards = {
    'Easy': 50,
    'Medium': 100,
    'Hard': 150,
    'Expert': 200,
    'Evil': 300,
  };

  static const int dailyChallengeXp = 75;
  static const int dailyChallengeCoins = 25;
  static const int perfectGameBonus = 50;

  // Achievements
  static const Map<String, Map<String, dynamic>> achievements = {
    'first_game': {'name': 'First Steps', 'description': 'Complete your first game', 'xp': 10},
    'perfect_10': {'name': 'Perfectionist', 'description': 'Win 10 perfect games', 'xp': 50},
    'streak_7': {'name': 'Week Warrior', 'description': 'Complete 7 day streak', 'xp': 100},
    'master_100': {'name': 'Master Clicks', 'description': 'Play 100 games', 'xp': 75},
    'speed_demon': {'name': 'Speed Demon', 'description': 'Complete Easy under 3 min', 'xp': 25},
  };

  // Animation Durations (milliseconds)
  static const int shortAnimation = 200;
  static const int mediumAnimation = 400;
  static const int longAnimation = 800;

  // Spacing
  static const double paddingSmall = 8.0;
  static const double paddingMedium = 16.0;
  static const double paddingLarge = 24.0;
  static const double paddingXLarge = 32.0;

  // Border Radius
  static const double radiusSmall = 8.0;
  static const double radiusMedium = 16.0;
  static const double radiusLarge = 24.0;
  static const double radiusXLarge = 32.0;

  // Font Sizes
  static const double fontSmall = 12.0;
  static const double fontMedium = 16.0;
  static const double fontLarge = 20.0;
  static const double fontXLarge = 28.0;
  static const double fontTitle = 36.0;

  // Store URLs
  static const String appStoreUrl = 'https://apps.apple.com/app/sudoku-master';
  static const String playStoreUrl = 'https://play.google.com/store/apps/details?id=com.sudokumaster.app';
}