// Sudoku Game Logic and Models
import 'dart:math';

enum Difficulty { easy, medium, hard, expert, evil }

enum GameStatus { notStarted, inProgress, paused, completed, failed }

class SudokuCell {
  final int row;
  final int col;
  int value;
  bool isFixed;
  bool isError;
  Set<int> pencilMarks;

  SudokuCell({
    required this.row,
    required this.col,
    this.value = 0,
    this.isFixed = false,
    this.isError = false,
    Set<int>? pencilMarks,
  }) : pencilMarks = pencilMarks ?? {};

  bool get isEmpty => value == 0;

  void setValue(int val) {
    if (!isFixed) {
      value = val;
      pencilMarks.clear();
    }
  }

  void togglePencilMark(int num) {
    if (value == 0) {
      if (pencilMarks.contains(num)) {
        pencilMarks.remove(num);
      } else {
        pencilMarks.add(num);
      }
    }
  }

  void clear() {
    if (!isFixed) {
      value = 0;
      pencilMarks.clear();
    }
  }

  SudokuCell copy() {
    return SudokuCell(
      row: row,
      col: col,
      value: value,
      isFixed: isFixed,
      isError: isError,
      pencilMarks: Set.from(pencilMarks),
    );
  }
}

class SudokuBoard {
  late List<List<SudokuCell>> cells;
  final int size = 9;
  final int boxSize = 3;

  SudokuBoard() {
    _initializeBoard();
  }

  void _initializeBoard() {
    cells = List.generate(
      size,
      (row) => List.generate(
        size,
        (col) => SudokuCell(row: row, col: col),
      ),
    );
  }

  SudokuCell getCell(int row, int col) => cells[row][col];

  List<SudokuCell> getRow(int row) => cells[row];

  List<SudokuCell> getColumn(int col) => cells.map((row) => row[col]).toList();

  List<SudokuCell> getBox(int boxRow, int boxCol) {
    List<SudokuCell> box = [];
    int startRow = boxRow * boxSize;
    int startCol = boxCol * boxSize;

    for (int r = startRow; r < startRow + boxSize; r++) {
      for (int c = startCol; c < startCol + boxSize; c++) {
        box.add(cells[r][c]);
      }
    }
    return box;
  }

  void setValue(int row, int col, int value) {
    cells[row][col].setValue(value);
  }

  void clearCell(int row, int col) {
    cells[row][col].clear();
  }

  bool isValidPlacement(int row, int col, int value) {
    // Check row
    for (int c = 0; c < size; c++) {
      if (c != col && cells[row][c].value == value) return false;
    }

    // Check column
    for (int r = 0; r < size; r++) {
      if (r != row && cells[r][col].value == value) return false;
    }

    // Check 3x3 box
    int boxRow = row ~/ boxSize;
    int boxCol = col ~/ boxSize;
    for (int r = boxRow * boxSize; r < boxRow * boxSize + boxSize; r++) {
      for (int c = boxCol * boxSize; c < boxCol * boxSize + boxSize; c++) {
        if (r != row && c != col && cells[r][c].value == value) return false;
      }
    }

    return true;
  }

  bool checkBoard() {
    bool valid = true;
    for (int r = 0; r < size; r++) {
      for (int c = 0; c < size; c++) {
        if (cells[r][c].value != 0) {
          int val = cells[r][c].value;
          cells[r][c].value = 0;
          if (!isValidPlacement(r, c, val)) {
            valid = false;
            cells[r][c].value = val;
            cells[r][c].isError = true;
          } else {
            cells[r][c].isError = false;
          }
        }
      }
    }
    return valid;
  }

  bool isComplete() {
    for (int r = 0; r < size; r++) {
      for (int c = 0; c < size; c++) {
        if (cells[r][c].value == 0) return false;
      }
    }
    return checkBoard();
  }

  void clear() {
    _initializeBoard();
  }

  SudokuBoard copy() {
    SudokuBoard newBoard = SudokuBoard();
    for (int r = 0; r < size; r++) {
      for (int c = 0; c < size; c++) {
        newBoard.cells[r][c] = cells[r][c].copy();
      }
    }
    return newBoard;
  }

  void loadFromArray(List<List<int>> grid) {
    for (int r = 0; r < size; r++) {
      for (int c = 0; c < size; c++) {
        int val = grid[r][c];
        cells[r][c].value = val;
        cells[r][c].isFixed = val != 0;
      }
    }
  }
}

class SudokuGenerator {
  final Random _random = Random();

  SudokuBoard generatePuzzle(Difficulty difficulty) {
    SudokuBoard board = SudokuBoard();

    // Generate a complete valid board first
    _fillBoard(board);

    // Then remove cells based on difficulty
    int cellsToRemove = _getCellsToRemove(difficulty);
    _removeCells(board, cellsToRemove);

    return board;
  }

  void _fillBoard(SudokuBoard board) {
    List<int> nums = [1, 2, 3, 4, 5, 6, 7, 8, 9];

    bool fillCell(int row, int col) {
      if (row == 9) return true;
      if (col == 9) return fillCell(row + 1, 0);

      List<int> shuffled = List.from(nums)..shuffle(_random);

      for (int num in shuffled) {
        if (board.isValidPlacement(row, col, num)) {
          board.setValue(row, col, num);
          if (fillCell(row, col + 1)) return true;
          board.clearCell(row, col);
        }
      }
      return false;
    }

    fillCell(0, 0);
  }

  int _getCellsToRemove(Difficulty difficulty) {
    switch (difficulty) {
      case Difficulty.easy:
        return 35;
      case Difficulty.medium:
        return 45;
      case Difficulty.hard:
        return 52;
      case Difficulty.expert:
        return 58;
      case Difficulty.evil:
        return 64;
    }
  }

  void _removeCells(SudokuBoard board, int count) {
    List<int> positions = [];
    for (int i = 0; i < 81; i++) positions.add(i);
    positions.shuffle(_random);

    int removed = 0;
    for (int pos in positions) {
      if (removed >= count) break;
      int row = pos ~/ 9;
      int col = pos % 9;
      if (board.cells[row][col].value != 0) {
        board.clearCell(row, col);
        removed++;
      }
    }
  }
}

class SudokuSolver {
  bool solve(SudokuBoard board) {
    return _solveCell(board, 0, 0);
  }

  bool _solveCell(SudokuBoard board, int row, int col) {
    if (row == 9) return true;
    if (col == 9) return _solveCell(board, row + 1, 0);

    if (board.cells[row][col].value != 0) {
      return _solveCell(board, row, col + 1);
    }

    for (int num = 1; num <= 9; num++) {
      if (board.isValidPlacement(row, col, num)) {
        board.setValue(row, col, num);
        if (_solveCell(board, row, col + 1)) return true;
        board.clearCell(row, col);
      }
    }
    return false;
  }

  List<List<int>>? getSolution(List<List<int>> puzzle) {
    SudokuBoard board = SudokuBoard();
    board.loadFromArray(puzzle);

    if (solve(board)) {
      return board.cells.map((row) => row.map((cell) => cell.value).toList()).toList();
    }
    return null;
  }

  int? findHint(SudokuBoard board) {
    // Find first empty cell
    for (int r = 0; r < 9; r++) {
      for (int c = 0; c < 9; c++) {
        if (board.cells[r][c].value == 0) {
          // Check if only one valid number exists
          List<int> validNums = [];
          for (int num = 1; num <= 9; num++) {
            if (board.isValidPlacement(r, c, num)) {
              validNums.add(num);
            }
          }
          if (validNums.length == 1) {
            return (r * 9 + c) * 10 + validNums[0];
          }
        }
      }
    }
    return null;
  }
}